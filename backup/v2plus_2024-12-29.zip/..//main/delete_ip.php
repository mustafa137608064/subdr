<?php

// دریافت اطلاعات از طریق متد POST
$page_name = $_POST['page_name'];
$ip_address = $_POST['ip_address'];

// اتصال به پایگاه داده
$db_connection = mysqli_connect('fdb1031.runhosting.com', '4428161_db', 'mustafa1234', '4428161_db');

// ضدعفونی کردن ورودی ها
$page_name = mysqli_real_escape_string($db_connection, $page_name);
$ip_address = mysqli_real_escape_string($db_connection, $ip_address);

// ایجاد عبارت SQL برای حذف IP
$sql_query = "DELETE FROM ip_addresses WHERE page_name = '$page_name' AND ip_address = '$ip_address'";

// اجرای عبارت SQL
mysqli_query($db_connection, $sql_query);

// بستن اتصال به پایگاه داده
mysqli_close($db_connection);

// هدایت کاربر به صفحه اصلی
header("Location: user.php?name=" . $page_name . "");

?>

