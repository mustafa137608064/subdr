$(document).ready(function() {
  $("#myButton").click(function() {
    var buttonId = $(this).attr('id');
    $.ajax({
      url: 'change_filter_status.php',
      type: 'POST',
      data: {buttonId: buttonId},
      success: function(response) {
        if (response === 'active') {
          $("#myButton").css('background-color', 'green');
        } else {
          $("#myButton").css('background-color', 'red');
        }
      }
    });
  });
});