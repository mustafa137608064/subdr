<?php
include 'config.php';
session_start();



if (!isset($_SESSION['user_id'])) {

    header('Location: login.php');

    exit;

}
?>
<html>        
        <div style="display:none;">
        <?php
					include 'refresh.php';     
				?>
         </div>
</html>

<?php
// دریافت نام کاربر از پارامتر URL
$name = $_GET['name'];
// اتصال به پایگاه داده
$conn = new mysqli($servername, $username, $password, $dbname);
// دریافت اطلاعات کاربر
$stmt = $conn->prepare("SELECT name, operator, time, note, last_update, filter_status FROM customers WHERE name = ?");
$stmt->bind_param("s", $name);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
    $dbip = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $stmtip = $dbip->prepare('SELECT status FROM ip_addresses WHERE page_name = ?');
    $stmtip->execute([$user["name"]]);
    $status = $stmtip->fetchColumn();



            //// محاسبه آخرین زمان آنلاین بودن  بخش1
    // اتصال به پایگاه داده
    $db = new mysqli($servername, $username, $password, $dbname);    
    // آخرین بازدید را از دیتابیس بر اساس نام کاربری جستجو کنید
    $sql = "SELECT date_time FROM ip_addresses WHERE page_name = '$name' ORDER BY date_time DESC LIMIT 1";
    $result = $db->query($sql);
	if ($result->num_rows > 0) {
    // آخرین رکورد را به عنوان آرایه استخراج کنید
    $row = $result->fetch_assoc();
    // تبدیل date_time به timestamp
    $last_visit_timestamp = strtotime($row['date_time']);
    // محاسبه زمان فعلی به صورت timestamp
    $current_timestamp =  date('Y-m-d H:i:s');        
    // تبدیل زمان UTC به زمان تهران (GMT+3:30)
    $date_time_tehran = date('Y-m-d H:i:s', strtotime($current_timestamp) + (3.5 * 3600));            
    // تبدیل زمان تهران به رشته قابل محاسبه    
    $date_time_online = strtotime($date_time_tehran);        
    // محاسبه اختلاف زمان به دقیقه
    $minutes_diff = round(($date_time_online - $last_visit_timestamp) / 60);       
    } else {
    $minutes_diff = -1;
	}

?>


<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- عنوان صفحه  -->
    <title><?php echo "" . $user["name"] . ""; ?></title>
    <link rel="stylesheet" href="https://cdn.rawgit.com/rastikerdar/vazir-font/v22.1.0/dist/font-face.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style_sidebar.css">
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
           <script>
        $(document).ready(function(){
            $("#btn_popup").click(function(){
                var name = document.getElementById("btn_popup").value; // دریافت مقدار متغیر name
                $.ajax({
                    url: "show_ips.php",
                    method: "POST",
                    data: {name: name}, // ارسال متغیر name به show_ip.php
                    success: function(data){
                        $("#popup_content").html(data);
                        $("#popup").show();  }});}); 
            $("#btn_close").click(function(){
                $("#popup").hide();});});
    </script>
        <style>
        .tab {
                overflow: hidden;
                border: 3px solid #f94e60;
                background-color: #f1f1f1;
                border-radius:15px;
                text-align: center;
                display: flex;
                justify-content: center;
                }
                .tab button {
                  background-color: #ccc;
                  float: left;
                  border: 1px solid grey;
                  outline: none;
                  cursor: pointer;
                  padding: 10px 10px;
                  transition: 0.3s;
                  font-size: 17px;
                  border-radius: 15px;
                  margin: 5px;
                }
                .tab button i{
                        color:black;
                }
                .tab button i.acive{
                        color:white;
                }
                .tab button i:hover{
                        color:white;
                }
                .tab button:hover {
                  background-color: #f94e60;
                  border: 1px solid black;
                  border-radius: 15px;
                  color: white;
                }
                .tab button.active {
                  background-color: #f94e60;
                  border: 1px solid white;
                  border-radius: 15px;
                  color: white;      
                }
                .tabcontent {
                  display: none;
                  padding: 6px 12px;
                  -webkit-animation: fadeEffect 1s;
                  animation: fadeEffect 1s;
                }
                @-webkit-keyframes fadeEffect {                
                  from {opacity: 0;}
                  to {opacity: 1;}
                }
                @keyframes fadeEffect {
                  from {opacity: 0;}
                  to {opacity: 1;}
                }
        </style>     
   </head>
<body>
        <button class="open-btn"><i class="	fa fa-plus"></i></button>
    <div class="container">
            
             
                            <?php
            echo "<link rel='stylesheet' href='style.css'>";
  // نمایش اطلاعات مشتریان
	echo "<form style='border-radius:15px;border:2px solid #f94e60;text-align:center;direction:rtl;padding:10px;margin-top:10px;margin-bottom:10px;'>";
    //نمایش نام 
    echo "<span style='display:inline-block;'>💳: <span style='color:#f94e60;margin-right:10px;'>" . $user["name"] . "</span></span>";                       
    //نمایش اپراتور فعلی
    echo "<span style='display:inline-block;margin-right:10px;'>  🛜: <span style='color:#f94e60;margin-right:10px;'>" . $user["operator"] . "</span></span>";                        
    //نمایش زمان فعلی
    echo "<span style='display:inline-block;margin-right:10px;'>  🗓️: <span style='color:#f94e60;margin-right:10px;'>" . $user["time"] . "</span></span><br>"; 
    // نمایش یادداشت های موجود
    echo "<span style='display:inline-block;'>  📝: <span style='color:#f94e60;margin-right:10px;'>" . $user["note"] . "</span></span>";    
    echo "<span style='display:inline-block;'>  🛡️:  </span>"; if ($status === 'on') {echo "<span style='font-size:small;color:green;'>✅تک کاربره</span>";} else {echo "<span style='font-size:small;color:red;'>❌چند کاربره</span>";};
    
    // نمایش آخرین بازدید آنلاینی  بخش2
    if ($minutes_diff >= 0 && $minutes_diff < 5) {
    echo "<span style='display:inline-block;margin-right:10px;'> 🟢: <span style='color:white;background-color:green;'>آنلاین</span></span>";
    } elseif ($minutes_diff >= 5 && $minutes_diff < 60) {
    echo "<span style='display:inline-block;margin-right:10px;'> 🟡: <span style='color:black;background-color:yellow;'> $minutes_diff </span><span style='color:black;background-color:yellow;'>دقیقه قبل</span></span>";
    } elseif ($minutes_diff >= 60 && $minutes_diff < 1440) {
    $hours = floor($minutes_diff / 60);
    echo "<span style='display:inline-block;margin-right:10px;'> 🟠: <span style='color:white;background-color:orange;'> $hours </span><span style='color:white;background-color:orange;'>ساعت قبل</span></span>";
    } elseif ($minutes_diff > 1440) {
    $days = floor($minutes_diff / 1440);
    echo "<span style='display:inline-block;margin-right:10px;'> 🔴: <span style='color:white;background-color:red;'> $days </span><span style='color:white;background-color:red;'>روز قبل</span></span>";
    } else {
    echo "<span style='display:inline-block;margin-right:10px;'> ⚫️: <span style='color:white;background-color:black;'>نامشخص</span></span>"; 
    }      
    echo "</form>";
            
    ?>
            
    <!-- تب بندی -->      
    <div class="tab">
      <button class="tablinks" onclick="openCity(event, 'Optime')" id="defaultOpen"><i class="fa fa-signal"></i></button>
      <button class="tablinks" onclick="openCity(event, 'AllowIP')"><i class="fa fa-shield"></i></button>
      <button class="tablinks" onclick="openCity(event, 'PrivateServer')"><i class="fa fa-server"></i></button>
      <button class="tablinks" onclick="openCity(event, 'Notes')"><i class="fa fa-edit"></i></button>
      <button class="tablinks" onclick="openCity(event, 'OtherOptions')"><i class="fa fa-navicon"></i></button>      
     </div>
        
    <div id="Optime" class="tabcontent">
            <?php       
    //تغییر اپراتور و زمان                      
	echo "<form  action='update.php' method='post' style='border-bottom:2px solid #f94e60; border-radius:15px;'>";
   	echo "<div style='direction:rtl;'><span>تغییر </span><span>🗓️</span><span> و </span><span>🛜</span></div>";
    //دکمه تعیین اپراتور
    echo "<form>";
    echo "<select name='operator'  style='width:25%;margin-right:15px;padding:5px;border-radius:15px;background-color:white;'>";
	echo "<option value='" . $user["operator"] . "'>" . $user["operator"] . "</option>";
    echo "<option value='ایرانسل' style='background-color:yellow;color:black;'>ایرانسل</option>";
    echo "<option value='همراه اول' style='background-color:blue;color:white;'>همراه اول</option>";
    echo "<option value='همه' style='background-color:green;color:white;'>همه</option>";
    echo "<option value='اختصاصی' style='background-color:white;color:black;'>اختصاصی</option>";        
    echo "<option value='فرگمنت' style='background-color:purple;color:white;'>فرگمنت</option>";
    echo "<option value='غیر فعال' style='background-color:red;color:white;'>غیر فعال</option>";
    echo "</select>";
    
    //دکمه تعیین تاریخ        
    echo "<select name='time'  style='width:25%;margin-right:15px;padding:5px;border-radius:15px;background-color:white;'>";
    echo "<option style='background-color:#f94e60;color:white;' value='" . $row["time"] . "'>" . $user["time"] . "</option>";
    echo "<option style='background-color:#f94e60;color:white;' value='time00'>♾️</option>";
	echo "<option style='background-color:#f94e60;color:white;' value='time01'>روز 1 ام</option>";
	echo "<option style='background-color:#f94e60;color:white;' value='time02'>روز 2 ام</option>";
	echo "<option style='background-color:#f94e60;color:white;' value='time03'>روز 3 ام</option>";
    echo "<option style='background-color:#f94e60;color:white;' value='time04'>روز 4 ام</option>";
    echo "<option style='background-color:#f94e60;color:white;' value='time05'>روز 5 ام</option>";
   	echo "<option style='background-color:#f94e60;color:white;' value='time06'>روز 6 ام</option>";
    echo "<option style='background-color:#f94e60;color:white;' value='time07'>روز 7 ام</option>";
    echo "<option style='background-color:#f94e60;color:white;' value='time08'>روز 8 ام</option>";
    echo "<option style='background-color:#f94e60;color:white;' value='time09'>روز 9 ام</option>";
    echo "<option style='background-color:#f94e60;color:white;' value='time10'>روز 10 ام</option>";
    echo "<option style='background-color:#f94e60;color:white;' value='time11'>روز 11 ام</option>";
   	echo "<option style='background-color:#f94e60;color:white;' value='time12'>روز 12 ام</option>";
    echo "<option style='background-color:#f94e60;color:white;' value='time13'>روز 13 ام</option>";
    echo "<option style='background-color:#f94e60;color:white;' value='time14'>روز 14 ام</option>";
    echo "<option style='background-color:#f94e60;color:white;' value='time15'>روز 15 ام</option>";
	echo "<option style='background-color:#f94e60;color:white;' value='time16'>روز 16 ام</option>";
	echo "<option style='background-color:#f94e60;color:white;' value='time17'>روز 17 ام</option>";
	echo "<option style='background-color:#f94e60;color:white;' value='time18'>روز 18 ام</option>";
	echo "<option style='background-color:#f94e60;color:white;' value='time19'>روز 19 ام</option>";
	echo "<option style='background-color:#f94e60;color:white;' value='time20'>روز 20 ام</option>";
	echo "<option style='background-color:#f94e60;color:white;' value='time21'>روز 21 ام</option>";
	echo "<option style='background-color:#f94e60;color:white;' value='time22'>روز 22 ام</option>";
	echo "<option style='background-color:#f94e60;color:white;' value='time23'>روز 23 ام</option>";
	echo "<option style='background-color:#f94e60;color:white;' value='time24'>روز 24 ام</option>";
	echo "<option style='background-color:#f94e60;color:white;' value='time25'>روز 25 ام</option>";
	echo "<option style='background-color:#f94e60;color:white;' value='time26'>روز 26 ام</option>";
	echo "<option style='background-color:#f94e60;color:white;' value='time27'>روز 27 ام</option>";
	echo "<option style='background-color:#f94e60;color:white;' value='time28'>روز 28 ام</option>";
    echo "<option style='background-color:#f94e60;color:white;' value='time29'>روز 29 ام</option>";
	echo "<option style='background-color:#f94e60;color:white;' value='time30'>روز 30 ام</option>";
	echo "<option style='background-color:#f94e60;color:white;' value='time31'>روز 31 ام</option>";
	echo "</select>"; 
            
    //ثبت تاریخ آخرین ویرایش
    echo "<input type='hidden' name='last_update' value='" . date('Y-m-d H:i:s') . "'>";

    // دکمه ذخیره
    echo "<input type='hidden' name='name' value='" . $user["name"] . "'>";
    echo "<input type='submit' value='✅ذخیره' style='padding:5px;width:25%;margin-right:15px;color:white;background-color:green;border:none;border-radius:15px;'>";
	echo "<br><br></form>";
    
    // نمایش تاریخ آخرین ویرایش        
    echo "<div style='color:grey;text-align:center;direction:ltr;font-size:12px;'><i class='fa fa-refresh'></i><span> " . $user["last_update"] . " </span></div>";       
    ?>        
    </div>  
            
    <div id="AllowIP" class="tabcontent">
            <?php    
	//افزودن IP مجاز
    echo "<div style='direction:rtl;'><span>🚧تعیین</span><span> IP </span><span>مجاز🚧</span><br></div>"; 
    echo "<button id='btn_popup' value='" . $user["name"] . "' style='direction:rtl;color:white;background-color:#f94e60;border:2px solid white;padding-left:25px;padding-right:25px;padding-top:10px;padding-bottom:10px;border-radius:15px;'>نمایش IP های ثبت شده برای ". $user["name"] ."</button><br><br>";
    echo "<form action='ip_status.php' method='post' style='direction:rtl;'>";
    echo "<span style='font-size:small;'>🛡️نوع کاربری: </span>";
    echo "<select name='status'  style='width:35%;margin-right:10px;padding:5px;border-radius:15px;background-color:white;'>";
    echo "<option style='background-color:#f94e60;color:white;' value='on'>✅تک کاربره✅</option>";
	echo "<option style='background-color:#f94e60;color:white;' value='off'>❌چندکاربره❌</option>";   
    echo "</select>";
    echo "<input type='hidden' name='name' value='" . $user["name"] . "'>";
    echo "<input type='submit' value='ذخیره✅' style='padding:5px;width:25%;margin-right:10px;color:white;background-color:green;border:none;border-radius:15px;'>";
    echo "</form>";
                 
    echo "<form action='allowip.php' method='post' style='direction:rtl;border-bottom:2px solid #f94e60; border-radius:15px;'>"; 
    echo "<input type='text' id='page_name' name='page_name' value='" . $user["name"] . "' readonly required style='text-align:center;border:none;background-color:#f0f0f0;'><br>";
    echo "<input type='text' id='allowed_ip' name='allowed_ip' placeholder='آدرس IP مجاز' required style='font-size:15px;text-align:center;direction:rtl;height:30px;border-radius:15px;border:1px solid black;'><br>";
    echo "<button type='submit' style='margin-top:15px;padding-left:25px;padding-right:25px;padding-top:10px;padding-bottom:10px;color:white;background-color:green;border:none;border-radius:15px;'>ذخیره IP✅</button>";       
    echo "<br><br></form>";
    ?>        
    </div>  
            
    <div id="PrivateServer" class="tabcontent">
            <?php        
    //افزودن سرور های اختصاصی به کاربر
    echo "<div style='direction:rtl;'><span>💬</span><span>سرور های </span><span>اختصاصی💬</span><br></div>";   
	$servername2 = $servername;$username2 = $username;$password2 = $password;$dbname2 = $dbname;
    //افزودن سرور شماره 1        
    $conn1 = new mysqli($servername2, $username2, $password2, $dbname2);
	$sql1 = "SELECT message1 FROM messages WHERE user_name = '" . $user["name"] . "'";
	$result1 = $conn1->query($sql1);
	if ($result1->num_rows > 0) {
	while ($row = $result1->fetch_assoc()) {    
    echo "<div style='direction:rtl;'>";
    echo "<span style='font-size: 12px; color: #666;'>سرور شماره 1:</span>";
    echo "<span style='font-size: 12px; color: #666;'>" . $row["message1"] . "</span>"; 
    echo "</div>"; }}
    echo "<div style='display:block;text-align:center; width:100%;'>";
    $conn1delete = new mysqli($servername2, $username2, $password2, $dbname2);
	$sql1delete = "SELECT message1 FROM messages WHERE user_name = '" . $user["name"] . "'";
	$result1delete = $conn1delete->query($sql1delete);
	if ($result1delete->num_rows > 0) {
	while ($row = $result1delete->fetch_assoc()) {
    echo "<form action='messages_delete.php' method='post'>";
    echo "<input type='hidden' id='user_name' name='user_name' value='" . $user["name"] . "'>";
    echo "<input type='submit' value='🗑️' style='float:right;padding-left:5px;padding-right:5px;padding-top:5px;padding-bottom:5px;color:white;background-color:red;border:none;border-radius:5px;margin-top:5px;marign-bottom:5px;'>";
    echo "</form>"; }}        
    echo "<form action='message1add.php' method='post' style='direction:rtl;'>"; 
    echo "<input type='text' id='user_name' name='user_name' value='" . $user["name"] . "' readonly required hidden style='color:white;text-align:center;border:none;background-color:#f0f0f0;'>";
    echo "<input type='text' id='message1' name='message1' placeholder='سرور شماره 1 را وارد کنید...'  style='float:center;font-size:15px;text-align:center;direction:rtl;height:40px;border-radius:15px;border:1px solid black;margin-left:5px;'>";
    echo "<button type='submit' style='float:left;margin-top:10px;padding-left:5px;padding-right:5px;padding-top:5px;padding-bottom:5px;color:white;background-color:green;border:none;border-radius:5px;'>✅</button>";       
    echo "</form></div>"; 
       
    //افزودن سرور شماره 2        
    $conn2 = new mysqli($servername2, $username2, $password2, $dbname2);
	$sql2 = "SELECT message2 FROM messages WHERE user_name = '" . $user["name"] . "'";
	$result2 = $conn2->query($sql2);
    $result2 = $conn2->query($sql2);
	if ($result2->num_rows > 0) {
	while ($row = $result2->fetch_assoc()) {
    echo "<div style='direction:rtl;'>";
    echo "<span style='font-size: 12px; color: #666;direction:rtl;'>سرور شماره 2:</span>";
    echo "<span style='font-size: 12px; color: #666;direction:rtl;'>" . $row["message2"] . "</span>";  
    echo "</div>"; }}
    echo "<div style='display:block;text-align:center; width:100%;'>";
    $conn2delete = new mysqli($servername2, $username2, $password2, $dbname2);
	$sql2delete = "SELECT message2 FROM messages WHERE user_name = '" . $user["name"] . "'";
	$result2delete = $conn2delete->query($sql2delete);
	if ($result2delete->num_rows > 0) {
	while ($row = $result2delete->fetch_assoc()) {
    echo "<form action='messages_delete.php' method='post'>";
    echo "<input type='hidden' id='user_name' name='user_name' value='" . $user["name"] . "'>";
    echo "<input type='submit' value='🗑️' style='float:right;padding-left:5px;padding-right:5px;padding-top:5px;padding-bottom:5px;color:white;background-color:red;border:none;border-radius:5px;margin-top:5px;marign-bottom:5px;'>";
    echo "</form>"; }}        
    echo "<form action='message2add.php' method='post' style='direction:rtl;'>"; 
    echo "<input type='text' id='user_name' name='user_name' value='" . $user["name"] . "' readonly required hidden style='color:white;text-align:center;border:none;background-color:#f0f0f0;'>";
    echo "<input type='text' id='message2' name='message2' placeholder='سرور شماره 2 را وارد کنید...'  style='float:center;font-size:15px;text-align:center;direction:rtl;height:40px;border-radius:15px;border:1px solid black;margin-left:5px;'>";
    echo "<button type='submit' style='float:left;margin-top:10px;padding-left:5px;padding-right:5px;padding-top:5px;padding-bottom:5px;color:white;background-color:green;border:none;border-radius:5px;'>✅</button>";       
    echo "</form></div>";  

    //افزودن سرور شماره 3        
	$conn3 = new mysqli($servername2, $username2, $password2, $dbname2);
	$sql3 = "SELECT message3 FROM messages WHERE user_name = '" . $user["name"] . "'";
	$result3 = $conn3->query($sql3);
    $result3 = $conn3->query($sql3);
	if ($result3->num_rows > 0) {
	while ($row = $result3->fetch_assoc()) {
    echo "<div style='direction:rtl;'>";
    echo "<span style='font-size: 12px; color: #666;direction:rtl;'>سرور شماره 3:</span>";
    echo "<span style='font-size: 12px; color: #666;direction:rtl;'>" . $row["message3"] . "</span>";  
    echo "</div>"; }}
    echo "<div style='display:block;text-align:center; width:100%;'>";
    $conn3delete = new mysqli($servername2, $username2, $password2, $dbname2);
	$sql3delete = "SELECT message3 FROM messages WHERE user_name = '" . $user["name"] . "'";
	$result3delete = $conn3delete->query($sql3delete);
	if ($result3delete->num_rows > 0) {
	while ($row = $result3delete->fetch_assoc()) {
    echo "<form action='messages_delete.php' method='post'>";
    echo "<input type='hidden' id='user_name' name='user_name' value='" . $user["name"] . "'>";
    echo "<input type='submit' value='🗑️' style='float:right;padding-left:5px;padding-right:5px;padding-top:5px;padding-bottom:5px;color:white;background-color:red;border:none;border-radius:5px;margin-top:5px;marign-bottom:5px;'>";
    echo "</form>"; }}        
    echo "<form action='message3add.php' method='post' style='direction:rtl;border-bottom:2px solid #f94e60; border-radius:15px;'>"; 
    echo "<input type='text' id='user_name' name='user_name' value='" . $user["name"] . "' readonly required hidden style='color:white;text-align:center;border:none;background-color:#f0f0f0;'>";
    echo "<input type='text' id='message3' name='message3' placeholder='سرور شماره 3 را وارد کنید...'  style='float:center;font-size:15px;text-align:center;direction:rtl;height:40px;border-radius:15px;border:1px solid black;margin-left:5px;'>";
    echo "<button type='submit' style='float:left;margin-top:10px;padding-left:5px;padding-right:5px;padding-top:5px;padding-bottom:5px;color:white;background-color:green;border:none;border-radius:5px;'>✅</button>";       
    echo "<br><br></form></div>";

    
	$conn1->close();
    $conn2->close();
    $conn3->close();
    $conn1delete->close();
    $conn2delete->close();
    $conn3delete->close();
            
    ?>        
    </div> 
            
    <div id="Notes" class="tabcontent">
            <?php
    //افزودن متن یادداشت
    echo "<span style='direction:rtl;'>📝افزودن یادداشت جدید📝</span><br>";
    echo "<form action='note.php' method='post' style='border-bottom:2px solid #f94e60; border-radius:15px;'>";
    echo "<input type='hidden' name='name' value='" . $user["name"] . "'>";
    echo "<textarea name='note' style='font-size:20px;text-align:center;direction:rtl;width:80%; height:50px;border-radius:15px;border:1px solid black;'></textarea>";
    echo "<br>";
    echo "<input type='submit' value='ذخیره یادداشت✅' style='margin-top:15px;padding-left:25px;padding-right:25px;padding-top:10px;padding-bottom:10px;color:white;background-color:green;border:none;border-radius:15px;'>";
    echo "<br><br></form>";
    ?>        
    </div>
            
    <div id="OtherOptions" class="tabcontent">
            <?php                                     
    //نمایش QR CODE
   	echo "<br><p><img src='qrcode.php?s=qrl&d=sub/" . $user["name"] . "'></p>";
       
    echo "<div style='display:flex;direction:rtl; text-align:center;'>"; 
    // ساب اسکراپشن
    echo "<a style='text-decoration:none;flex:20%;margin:5px;padding-left:10px;padding-right:10px;padding-top:5px;padding-bottom:5px;color:white;background-color:blue;border:none;border-radius:15px;margin-top:15px;marign-bottom:15px;' target='_blank' href='sub/" . $user["name"] . ".php'>لینک ساب اسکراپشن🔗</a>";
    //دانلود برنامه اندروید                     
    echo "<a style='text-decoration:none;flex:20%;margin:5px;padding-left:10px;padding-right:10px;padding-top:5px;padding-bottom:5px;color:white;background-color:green;border:none;border-radius:15px;margin-top:15px;marign-bottom:15px;' target='_blank' href='https://1ea.ir/" . $user["name"] . "'>دانلود نرم افزار اندروید📥</a>";
    echo "</div>";        
                      
    //دکمه حذف
    echo "<form action='delete.php' method='post'>";
    echo "<input type='hidden' name='name' value='" . $user["name"] . "'>";
    echo "<input type='submit' value='" . $user["name"] . " حذف🗑️' style='flex:30%;margin:5px;padding-left:25px;padding-right:25px;padding-top:10px;padding-bottom:10px;color:white;background-color:red;border:none;border-radius:15px;margin-top:15px;marign-bottom:15px;'>";
    echo "</form><br><br><br>";                                              
	?>
    </div>
            <!--اسکریپت تب بندی -->
          <script>
          function openCity(evt, cityName) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
              tabcontent[i].style.display = "none";
            }
            tablinks = document.getElementsByClassName("tablinks");
            for (i = 0; i < tablinks.length; i++) {
              tablinks[i].className = tablinks[i].className.replace(" active", "");
            }
            document.getElementById(cityName).style.display = "block";
            evt.currentTarget.className += " active";
          }
          document.getElementById("defaultOpen").click();
          </script>
        	
          <div id="popup" style="height:500px;width:60%;overflow:scroll;display:none;background-color:#f0f0f0;padding:20px;border:3px solid black;position:fixed;top:50%;left:50%;transform:translate(-50%, -50%);border-radius:15px;">
        <div id="popup_content"></div>
        <button id="btn_close" style="background-color:red;border-radius:15px;padding-left:25px;padding-right:25px;padding-top:10px;padding-bottom:10px;color:white;border:none;">بستن</button>
    </div>
            
  </div>
        <?php
        
        ?>
      <!----sidebar---->  
    <div class="sidebar">
        <button class="close-btn"><i class="fa fa-close"></i></button>    
            <center>
                       <form method="POST" action="change_filter_status.php">
                           <input type="hidden" name="name" value="<?php echo $name; ?>">
                           <button id="statusButton" class="<?php echo ($filter_status == 'active') ? 'btn-success' : 'btn-danger'; ?>" style="backgroud-color:none;border:3px solid #f94e60;border-radius:5px;padding-right:10px;padding-left:10px;">
                               <?php echo ($user["filter_status"] == 'active') ? 'فعال' : 'غیرفعال'; ?>
                           </button>
                       </form> 
         
            <?php
            $conn9 = new mysqli($servername, $username, $password, $dbname);
            $sql9 = "SELECT * FROM history WHERE name = '$name' ORDER BY change_time DESC LIMIT 5";
            $result9 = $conn9->query($sql9);
            if ($result9->num_rows > 0) {
                echo "<table class='his-table'><tr class='his-table-row'><th class='his-table-row'>ID</th><th class='his-table-row'>نوع</th><th class='his-table-row'>زمان</th></tr>";
                while($row = $result9->fetch_assoc()) {
                    echo "<tr class='his-table-row'><td class='his-table-row'>" . $row["id"]. "</td><td class='his-table-row'>" . $row["operator"]. "</td><td class='his-table-row'>" . $row["change_time"]. "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "هیچگونه تاریخچه تغییراتی برای این کاربر وجود ندارد!";
            }
            $conn9->close();
            ?>
     </center> 
        
    </div>
    <script src="script_sidebar.js"></script>
         <script src="change_filter_status.js"></script>
                 
       <!---تولبار پایین صفحه---> 
   <div class="toolbar" style="position: fixed;bottom: 0;left: 0;width: 100%;height: 70px;background-color: #f94e60;display: flex;justify-content: space-around;align-items: center;border-top-left-radius: 50px;border-top-right-radius: 50px;border: 2px solid white;direction: rtl;">
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='customers.php'"><i class="fa fa-book"></i></button>
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='index.php'"><i class="fa fa-home"></i></button>
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='profile.php'"><i class="fa fa-user"></i></button>
  </div>      
        
                        
</body>
</html>

<?php
      

    // آپدیت دیتابیس
  $stmt = "UPDATE customers SET operator = '$operator', time = '$time', note = '$note' WHERE name = '$name'";
  $conn->query($sql);


// بستن اتصال به دیتابیس
$conn->close();


// بستن اتصال به پایگاه داده آخرین بازدید آنلاینی  بخش3
$db->close();    
?>


