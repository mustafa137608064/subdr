<?php
session_start();



if (!isset($_SESSION['user_id'])) {

    header('Location: login.php');

    exit;

}

include "jdf.php";
include "config.php";
$today = jdate('Y/m/d');
$daysOfWeek = array('یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه');
$dayNumber = date('w');
?>



<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- عنوان صفحه  -->
    <title>ویرایش زمان بندی ها</title>

    <link rel="stylesheet" href="https://cdn.rawgit.com/rastikerdar/vazir-font/v22.1.0/dist/font-face.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
        <link rel="stylesheet" href="style.css">
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <style>
.daybutton {
        background-color: #f94e60;
        border-radius: 15px;
        padding: 20px;
        border: 1px solid white;
        color: white;
        width: 30;
        display: inline-block;
        flex-direction: row;
        direction:rtl;
        

</style>

</head>
<body>
    <div class="container">
            

            <div class="buttons" style="direction:rtl;">
                <h3 style="font-size: 12px; color: #666;">تاریخ های ماهیانه</h3>
                    <?php
                    echo "<div>";
            			echo "<span style='margin:5px;'>$daysOfWeek[$dayNumber]</span>";
        				echo "<span style='margin:5px;'>$today</span>";
        			echo "</div>";
                    ?>
                    <button class="daybutton" onclick="location.href='date/time00.php'">♾️</button>
                    <button class="daybutton" onclick="location.href='date/time01.php'">01</button>
                    <button class="daybutton" onclick="location.href='date/time02.php'">02</button>
                    <button class="daybutton" onclick="location.href='date/time03.php'">03</button>
                    <button class="daybutton" onclick="location.href='date/time04.php'">04</button>
                    <button class="daybutton" onclick="location.href='date/time05.php'">05</button>
                    <button class="daybutton" onclick="location.href='date/time06.php'">06</button>
                    <button class="daybutton" onclick="location.href='date/time07.php'">07</button>                   
                    <button class="daybutton" onclick="location.href='date/time08.php'">08</button>
                    <button class="daybutton" onclick="location.href='date/time09.php'">09</button>
                    <button class="daybutton" onclick="location.href='date/time10.php'">10</button>
                    <button class="daybutton" onclick="location.href='date/time11.php'">11</button>
                    <button class="daybutton" onclick="location.href='date/time12.php'">12</button>
                    <button class="daybutton" onclick="location.href='date/time13.php'">13</button>
                    <button class="daybutton" onclick="location.href='date/time14.php'">14</button>
                    <button class="daybutton" onclick="location.href='date/time15.php'">15</button>
                    <button class="daybutton" onclick="location.href='date/time16.php'">16</button>
                    <button class="daybutton" onclick="location.href='date/time17.php'">17</button>
                    <button class="daybutton" onclick="location.href='date/time18.php'">18</button>
                    <button class="daybutton" onclick="location.href='date/time19.php'">19</button>
                    <button class="daybutton" onclick="location.href='date/time20.php'">20</button>
                    <button class="daybutton" onclick="location.href='date/time21.php'">21</button>
                    <button class="daybutton" onclick="location.href='date/time22.php'">22</button>
                    <button class="daybutton" onclick="location.href='date/time23.php'">23</button>
                    <button class="daybutton" onclick="location.href='date/time24.php'">24</button>
                    <button class="daybutton" onclick="location.href='date/time25.php'">25</button>
                    <button class="daybutton" onclick="location.href='date/time26.php'">26</button>
                    <button class="daybutton" onclick="location.href='date/time27.php'">27</button>
                    <button class="daybutton" onclick="location.href='date/time28.php'">28</button>
                    <button class="daybutton" onclick="location.href='date/time29.php'">29</button>
                    <button class="daybutton" onclick="location.href='date/time30.php'">30</button>
                    <button class="daybutton" onclick="location.href='date/time31.php'">31</button>

            
            </div>
        
        <!--عنوان پایین صفحه -->
        <p style="font-size: 12px; color: #666;">Last Updated Feb 5th </p>
        
        </div>
        
        
           
       <!---تولبار پایین صفحه---> 
   <div class="toolbar" style="position: fixed;bottom: 0;left: 0;width: 100%;height: 70px;background-color: #f94e60;display: flex;justify-content: space-around;align-items: center;border-top-left-radius: 50px;border-top-right-radius: 50px;border: 2px solid white;direction: rtl;">
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='customers.php'"><i class="fa fa-book"></i></button>
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='index.php'"><i class="fa fa-home"></i></button>
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='profile.php'"><i class="fa fa-user"></i></button>
  </div>      
        
</body>
</html>
<html>
        <div style="display:none;">
        <?php
					include 'refresh.php';     
				?>
         </div>
</html>
<html>
<div style="display:none;">
<?php 
include '/date/time00edit.php'; 
include '/date/time01edit.php'; 
include '/date/time02edit.php'; 
include '/date/time03edit.php'; 
include '/date/time04edit.php'; 
include '/date/time05edit.php'; 
include 'date/time06edit.php'; 
include 'date/time07edit.php'; 
include 'date/time08edit.php'; 
include 'date/time09edit.php'; 
include 'date/time10edit.php'; 
include 'date/time11edit.php'; 
include 'date/time12edit.php'; 
include 'date/time13edit.php'; 
include 'date/time14edit.php'; 
include 'date/time15edit.php'; 
include 'date/time16edit.php'; 
include 'date/time17edit.php'; 
include 'date/time18edit.php'; 
include 'date/time19edit.php'; 
include 'date/time20edit.php'; 
include 'date/time21edit.php'; 
include 'date/time22edit.php'; 
include 'date/time23edit.php'; 
include 'date/time24edit.php'; 
include 'date/time25edit.php'; 
include 'date/time26edit.php'; 
include 'date/time27edit.php'; 
include 'date/time28edit.php'; 
include 'date/time29edit.php'; 
include 'date/time30edit.php'; 
include 'date/time31edit.php'; 
?>
</div>
</html>