<script>
function changeColor() {
const textElement = document.getElementById("color-text");
const currentColor = textElement.style.color;
if (currentColor === "red") {
textElement.style.color = "green";
} else {
textElement.style.color = "red";
}
}
setInterval(changeColor, 500); // تغییر رنگ هر ثانیه
</script>




<?php
                ///شمارش تعداد افراد آنلاین
$db2 = new mysqli($servername, $username, $password, $dbname);
$sql2 = "SELECT page_name, date_time FROM ip_addresses ORDER BY date_time DESC";
$result2 = $db2->query($sql2);
$count_pages_under_5_minutes = 0;
if ($result2->num_rows > 0) {
    while ($row = $result2->fetch_assoc()) {
        $last_visit_timestamp = strtotime($row['date_time']);
        $current_timestamp = date('Y-m-d H:i:s');
        $date_time_tehran = date('Y-m-d H:i:s', strtotime($current_timestamp) + (3.5 * 3600));
        $date_time_online = strtotime($date_time_tehran);
        $minutes_diff = round(($date_time_online - $last_visit_timestamp) / 60);
        if ($minutes_diff < 5) {
            $count_pages_under_5_minutes++;
        }}}
echo "<div style='direction:rtl;' id='color-text'><i class='fa fa-circle'></i>" . $count_pages_under_5_minutes . "<span> آنلاین</span><i class='fa fa-circle'></i></div>";

            ?>