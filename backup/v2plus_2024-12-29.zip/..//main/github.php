<?php
// مسیر پوشه‌ای که فایل‌ها در آن قرار دارند
$folder = __DIR__ . '/sub';

// بررسی وجود پوشه
if (!is_dir($folder)) {
    die('پوشه مورد نظر وجود ندارد.');
}

// نام فایل ZIP خروجی
$zipFileName = 'github.zip';

// ایجاد آرشیو ZIP
$zip = new ZipArchive();
if ($zip->open($zipFileName, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
    die('خطا در ایجاد فایل ZIP.');
}

// افزودن فایل‌های موجود در پوشه به ZIP
$files = scandir($folder);
foreach ($files as $file) {
    $filePath = $folder . '/' . $file;
    if (is_file($filePath)) {
        $zip->addFile($filePath, $file); // اضافه کردن فایل با مسیر داخلی
    }
}

// بستن آرشیو ZIP
$zip->close();

// تنظیم هدرهای دانلود
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
header('Content-Length: ' . filesize($zipFileName));

// ارسال فایل برای دانلود
readfile($zipFileName);

// حذف فایل ZIP پس از دانلود
unlink($zipFileName);

exit;
?>
