<?php
$githubUsername = 'mustafa137608064';
$repositoryName = 'subdr';
$folderName = 'users';
$personalAccessToken = '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';
$localFolder = 'sub';

// تابع برای فهرست کردن فایل‌های موجود در پوشه
function listFilesInFolder($githubUsername, $repositoryName, $folderName, $personalAccessToken) {
    $url = "https://api.github.com/repos/$githubUsername/$repositoryName/contents/$folderName";
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: token ' . $personalAccessToken,
        'User-Agent: PHP Script'
    ]);
    $response = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($response, true);
    if (is_array($data)) {
        return $data;
    }
    return [];
}

// تابع برای حذف فایل از مخزن
function deleteFileFromGitHub($filePath, $sha, $githubUsername, $repositoryName, $personalAccessToken) {
    $url = "https://api.github.com/repos/$githubUsername/$repositoryName/contents/$filePath";
    $data = [
        'message' => "Delete $filePath",
        'sha' => $sha
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: token ' . $personalAccessToken,
        'User-Agent: PHP Script'
    ]);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 200) {
        return true;
    } else {
        return false;
    }
}

// تابع برای آپلود فایل در گیت‌هاب
function uploadFileToGitHub($filePath, $githubUsername, $repositoryName, $folderName, $personalAccessToken) {
    $fileContent = file_get_contents($filePath);
    $base64Content = base64_encode($fileContent);
    $fileName = basename($filePath);

    $url = "https://api.github.com/repos/$githubUsername/$repositoryName/contents/$folderName/$fileName";

    $data = [
        'message' => "Upload $fileName",
        'content' => $base64Content
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: token ' . $personalAccessToken,
        'User-Agent: PHP Script'
    ]);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 201) {
        return true;
    } else {
        return false;
    }
}

// تابع برای حذف پوشه (در واقع حذف تمامی فایل‌های داخل آن)
function deleteFolderAndContents($githubUsername, $repositoryName, $folderName, $personalAccessToken) {
    $files = listFilesInFolder($githubUsername, $repositoryName, $folderName, $personalAccessToken);

    foreach ($files as $file) {
        if (isset($file['path']) && isset($file['sha'])) {
            deleteFileFromGitHub($file['path'], $file['sha'], $githubUsername, $repositoryName, $personalAccessToken);
        }
    }
}

function displayMessage($message, $status = 'pending') {
    echo "<script>
            document.getElementById('status').innerHTML = '<p>' + '$message' + ' - ' + '$status' + '</p>';
          </script>";
}
?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Process</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .status { margin-top: 20px; }
        .success { color: green; }
        .error { color: red; }
        .pending { color: orange; }
        .step { margin-bottom: 15px; }
        .step span { font-weight: bold; }
        #loading {
            display: block;
            margin: 0 auto;
            text-align: center;
            font-size: 20px;
            color: #333;
        }
    </style>
</head>
<body>

<h1>Upload Process</h1>

<!-- Loading Message -->
<div id="loading">صفحه در حال بارگذاری است...</div>

<!-- Status Updates -->
<div id="status" class="status">
    <!-- Status messages will be updated here -->
</div>

<script>
    window.onload = function() {
        
        document.getElementById('loading').style.display = 'none';
        document.getElementById('status').style.display = 'block';

        setTimeout(function() {
            <?php 
                displayMessage('شروع فرآیند...', 'pending');
                
                // حذف پوشه users و محتویات آن
                deleteFolderAndContents($githubUsername, $repositoryName, $folderName, $personalAccessToken);
                displayMessage('پوشه users حذف شد.', 'success');

                // آپلود فایل‌ها
                displayMessage('در حال آپلود فایل‌ها...', 'pending');
                if (is_dir($localFolder)) {
                    $files = scandir($localFolder);
                    $totalFiles = count($files) - 2; // . و .. را از شمارش حذف می‌کنیم
                    $uploaded = 0;
                    $failed = 0;

                    foreach ($files as $index => $file) {
                        if ($file !== '.' && $file !== '..') {
                            $filePath = $localFolder . DIRECTORY_SEPARATOR . $file;
                            if (is_file($filePath)) {
                                displayMessage("در حال آپلود فایل $file ($index/$totalFiles)...", 'pending');
                                $status = uploadFileToGitHub($filePath, $githubUsername, $repositoryName, $folderName, $personalAccessToken) ? 'success' : 'error';
                                if ($status === 'success') {
                                    $uploaded++;
                                } else {
                                    $failed++;
                                }
                            }
                        }
                    }

                    displayMessage("آپلود با موفقیت انجام شد. فایل‌های نا موفق: $failed",'success');
                } else {
                    displayMessage("پوشه $localFolder وجود ندارد.", 'error');
                }
            ?>
        
</script>

<hr>
<h2>لینک به پوشه آپلود شده در گیت‌هاب:</h2>
<p><a href="https://github.com/<?php echo $githubUsername; ?>/<?php echo $repositoryName; ?>/tree/main/<?php echo $folderName; ?>" target="_blank">مشاهده پوشه در گیت‌هاب</a></p>

</body>
</html>
