<?php
session_start();



if (!isset($_SESSION['user_id'])) {

    header('Location: login.php');

    exit;

}


include 'config.php';

// ایجاد اتصال به دیتابیس
$conn = new mysqli($servername, $username, $password, $dbname);

// دریافت نام کاربر از URL
$user_name = $_POST['user_name'];



// حذف از دیتابیس
$sql = "DELETE FROM messages WHERE user_name = '$user_name'";


$conn->query($sql);

// پیغام موفقیت آمیز حذف کاربر

echo "<script>";

echo "alert('پیغام های  " . $user_name . " با موفقیت حذف شد.');";

echo "window.location.href = 'user.php?name=" . $user_name . "';";

echo "</script>";

?>
