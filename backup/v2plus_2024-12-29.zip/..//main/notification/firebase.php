<?php
require 'vendor/autoload.php';

use Kreait\Firebase\Factory;

$factory = (new Factory)
    ->withServiceAccount('google-services.json')
    ->withDatabaseUri('https://your-firebase-project.firebaseio.com');

$database = $factory->createDatabase();
