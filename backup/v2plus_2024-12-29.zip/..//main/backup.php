<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include 'config.php';

// نام فایل فشرده
$backup_file = "v2plus_" . date("Y-m-d") . ".zip";

// اتصال به پایگاه داده
$db = new mysqli($servername, $username, $password, $dbname);

// بررسی اتصال
if ($db->connect_error) {
    die("خطا در اتصال به پایگاه داده: " . $db->connect_error);
}

// تهیه لیست از تمام فایل ها
$files = array();
$dir = "../";
$recursive = true;

// تابع بازگشتی برای پیمایش در دایرکتوری ها
function get_files($dir, $recursive) {
    global $files;

    $handle = opendir($dir);
    while (($file = readdir($handle)) !== false) {
        if ($file != "." && $file != "..") {
            $path = $dir . "/" . $file;
            if (is_dir($path) && $recursive) {
                get_files($path, $recursive);
            } else {
                $files[] = $path;
            }
        }
    }
    closedir($handle);
}

// دریافت لیست تمام فایل ها
get_files($dir, $recursive);

// تهیه نسخه پشتیبان از پایگاه داده
$dump = "";
$tables = array();
$result = $db->query("SHOW TABLES");
while ($row = $result->fetch_assoc()) {
    $tables[] = $row["Tables_in_" . $dbname];
}

foreach ($tables as $table) {
    $dump .= "DROP TABLE IF EXISTS `" . $table . "`;\n";
    $result = $db->query("SHOW CREATE TABLE `" . $table . "`");
    $row = $result->fetch_assoc();
    $dump .= $row["Create Table"] . ";\n\n";

    $result = $db->query("SELECT * FROM `" . $table . "`");
    while ($row = $result->fetch_assoc()) {
        $dump .= "INSERT INTO `" . $table . "` (`" . implode("`, `", array_keys($row)) . "`) VALUES ('" . implode("', '", array_values($row)) . "');\n";
    }
}

// فشرده سازی فایل ها و دیتابیس
$zip = new ZipArchive();
$zip->open($backup_file, ZipArchive::CREATE);
foreach ($files as $file) {
    $zip->addFile($file, $file);
}
$zip->addFromString("database.sql", $dump);
$zip->close();

// ارسال فایل فشرده به گیت‌هاب
$github_token = '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';  // توکن دسترسی گیت‌هاب خود را وارد کنید
$repo_owner = 'mustafa137608064';
$repo_name = 'subdr';
$path_in_repo = 'backup/' . $backup_file;  // مسیر پوشه در گیت‌هاب

$api_url = "https://api.github.com/repos/$repo_owner/$repo_name/contents/$path_in_repo";

// خواندن محتویات فایل برای ارسال به گیت‌هاب
$file_content = base64_encode(file_get_contents($backup_file));

// ساخت داده برای ارسال به API گیت‌هاب
$data = [
    'message' => 'Backup ' . $backup_file,
    'content' => $file_content,
    'branch' => 'main',  // یا نام برنچ مورد نظر شما
];

$options = [
    'http' => [
        'method' => 'PUT',
        'header' => [
            'Authorization: token ' . $github_token,
            'Content-Type: application/json',
        ],
        'content' => json_encode($data),
    ],
];

$context = stream_context_create($options);
$response = file_get_contents($api_url, false, $context);

// بررسی پاسخ از گیت‌هاب
if ($response === FALSE) {
    die('Error uploading file to GitHub.');
} else {
    echo 'Backup uploaded successfully to GitHub!';
}

// حذف فایل فشرده از سرور
unlink($backup_file);

?>
