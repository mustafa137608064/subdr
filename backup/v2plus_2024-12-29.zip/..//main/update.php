<?php
session_start();



if (!isset($_SESSION['user_id'])) {

    header('Location: login.html');

    exit;

}

include 'config.php';


// ایجاد اتصال به دیتابیس
$conn = new mysqli($servername, $username, $password, $dbname);
// دریافت نام و نوع شبکه مشتریان از دیتابیس
$stmt = "SELECT name, operator, time, note, last_update FROM customers";
$result = $conn->query($stmt);
// دریافت اطلاعات از فرم
$name = $_POST["name"] ?? "";
$operator = $_POST["operator"];
$time = $_POST["time"];
$last_update = $_POST['last_update'];
//تبدیل زمان آخرین ویرایش بر اساس منطقه تهران
$last_update_tehran = date('Y-m-d H:i:s', strtotime($last_update) + (3.5 * 3600));            
  

// ذخیره اطلاعات در فایل و آپدیت دیتابیس

if (isset($_POST["operator"])) {

  $name = $_POST["name"];

  $operator = $_POST["operator"];

  $time = $_POST["time"];
        


  
  // ذخیره اطلاعات در فایل
switch ($operator) {
  case "همه":
    switch ($time) {
      case "time00";
        $text = $text0_time0;
        break;
      case "time01";
        $text = $text0_time1;
        break;
      case "time02";
        $text = $text0_time2;
        break;
      case "time03";
        $text = $text0_time3;
        break;
      case "time04";
	  	$text = $text0_time4;
        break;
      case "time05";
        $text = $text0_time5;
        break;
      case "time06";
        $text = $text0_time6;
        break;
	case "time07";
	  $text = $text0_time7;
        break;
      case "time08";
        $text = $text0_time8;
        break;
      case "time09";
        $text = $text0_time9;
        break;
	case "time10";
	  $text = $text0_time10;
        break;
      case "time11";
        $text = $text0_time11;
        break;
      case "time12";
        $text = $text0_time12;
        break;
	case "time13";
	  $text = $text0_time13;
        break;
      case "time14";
        $text = $text0_time14;
        break;
      case "time15";
        $text = $text0_time15;
        break;
	case "time16";
	  $text = $text0_time16;
        break;
      case "time17";
        $text = $text0_time17;
        break;
      case "time18";
        $text = $text0_time18;
        break;
	case "time19";
	  $text = $text0_time19;
        break;
      case "time20";
        $text = $text0_time20;
        break;
      case "time21";
        $text = $text0_time21;
        break;
	case "time22";
	  $text = $text0_time22;
        break;
      case "time23";
        $text = $text0_time23;
        break;
      case "time24";
        $text = $text0_time24;
        break;
	case "time25";
	  $text = $text0_time25;
        break;
      case "time26";
        $text = $text0_time26;
        break;
      case "time27";
        $text = $text0_time27;
        break;
	case "time28";
	  $text = $text0_time28;
        break;
      case "time29";
        $text = $text0_time29;
        break;
      case "time30";
        $text = $text0_time30;
        break;
	case "time31";
        $text = $text0_time31;
        break;
    }
    break;           
  case "ایرانسل":
    switch ($time) {
      case "time00";
        $text = $text1_time0;
        break;
      case "time01";
        $text = $text1_time1;
        break;
      case "time02";
        $text = $text1_time2;
        break;
      case "time03";
        $text = $text1_time3;
        break;
      case "time04";
	  	$text = $text1_time4;
        break;
      case "time05";
        $text = $text1_time5;
        break;
      case "time06";
        $text = $text1_time6;
        break;
	case "time07";
	  $text = $text1_time7;
        break;
      case "time08";
        $text = $text1_time8;
        break;
      case "time09";
        $text = $text1_time9;
        break;
	case "time10";
	  $text = $text1_time10;
        break;
      case "time11";
        $text = $text1_time11;
        break;
      case "time12";
        $text = $text1_time12;
        break;
	case "time13";
	  $text = $text1_time13;
        break;
      case "time14";
        $text = $text1_time14;
        break;
      case "time15";
        $text = $text1_time15;
        break;
	case "time16";
	  $text = $text1_time16;
        break;
      case "time17";
        $text = $text1_time17;
        break;
      case "time18";
        $text = $text1_time18;
        break;
	case "time19";
	  $text = $text1_time19;
        break;
      case "time20";
        $text = $text1_time20;
        break;
      case "time21";
        $text = $text1_time21;
        break;
	case "time22";
	  $text = $text1_time22;
        break;
      case "time23";
        $text = $text1_time23;
        break;
      case "time24";
        $text = $text1_time24;
        break;
	case "time25";
	  $text = $text1_time25;
        break;
      case "time26";
        $text = $text1_time26;
        break;
      case "time27";
        $text = $text1_time27;
        break;
	case "time28";
	  $text = $text1_time28;
        break;
      case "time29";
        $text = $text1_time29;
        break;
      case "time30";
        $text = $text1_time30;
        break;
	case "time31";
        $text = $text1_time31;
        break;
    }
    break;
  case "همراه اول":
    switch ($time) {
      case "time00";
        $text = $text2_time0;
        break;
      case "time01";
        $text = $text2_time1;
        break;
      case "time02";
        $text = $text2_time2;
        break;
      case "time03";
        $text = $text2_time3;
        break;
      case "time04";
	  	$text = $text2_time4;
        break;
      case "time05";
        $text = $text2_time5;
        break;
      case "time06";
        $text = $text2_time6;
        break;
	case "time07";
	  $text = $text2_time7;
        break;
      case "time08";
        $text = $text2_time8;
        break;
      case "time09";
        $text = $text2_time9;
        break;
	case "time10";
	  $text = $text2_time10;
        break;
      case "time11";
        $text = $text2_time11;
        break;
      case "time12";
        $text = $text2_time12;
        break;
	case "time13";
	  $text = $text2_time13;
        break;
      case "time14";
        $text = $text2_time14;
        break;
      case "time15";
        $text = $text2_time15;
        break;
	case "time16";
	  $text = $text2_time16;
        break;
      case "time17";
        $text = $text2_time17;
        break;
      case "time18";
        $text = $text2_time18;
        break;
	case "time19";
	  $text = $text2_time19;
        break;
      case "time20";
        $text = $text2_time20;
        break;
      case "time21";
        $text = $text2_time21;
        break;
	case "time22";
	  $text = $text2_time22;
        break;
      case "time23";
        $text = $text2_time23;
        break;
      case "time24";
        $text = $text2_time24;
        break;
	case "time25";
	  $text = $text2_time25;
        break;
      case "time26";
        $text = $text2_time26;
        break;
      case "time27";
        $text = $text2_time27;
        break;
	case "time28";
	  $text = $text2_time28;
        break;
      case "time29";
        $text = $text2_time29;
        break;
      case "time30";
        $text = $text2_time30;
        break;
	case "time31";
        $text = $text2_time31;
        break;
    }
    break;
  case "غیر فعال":
    switch ($time) {
    case "time00";
        $text = $text3;
        break;
	case "time01";
        $text = $text3;
        break;
      case "time02";
        $text = $text3;
        break;
      case "time03";
        $text = $text3;
        break;
      case "time04";
	  	$text = $text3;
        break;
      case "time05";
        $text = $text3;
        break;
      case "time06";
        $text = $text3;
        break;
	case "time07";
	  $text = $text3;
        break;
      case "time08";
        $text = $text3;
        break;
      case "time09";
        $text = $text3;
        break;
	case "time10";
	  $text = $text3;
        break;
      case "time11";
        $text = $text3;
        break;
      case "time12";
        $text = $text3;
        break;
	case "time13";
	  $text = $text3;
        break;
      case "time14";
        $text = $text3;
        break;
      case "time15";
        $text = $text3;
        break;
	case "time16";
	  $text = $text3;
        break;
      case "time17";
        $text = $text3;
        break;
      case "time18";
        $text = $text3;
        break;
	case "time19";
	  $text = $text3;
        break;
      case "time20";
        $text = $text3;
        break;
      case "time21";
        $text = $text3;
        break;
	case "time22";
	  $text = $text3;
        break;
      case "time23";
        $text = $text3;
        break;
      case "time24";
        $text = $text3;
        break;
	case "time25";
	  $text = $text3;
        break;
      case "time26";
        $text = $text3;
        break;
      case "time27";
        $text = $text3;
        break;
	case "time28";
	  $text = $text3;
        break;
      case "time29";
        $text = $text3;
        break;
      case "time30";
        $text = $text3;
        break;
	case "time31";
        $text = $text3;
        break;
    }
    break;
    case "فرگمنت":
    switch ($time) {
    case "time00";
        $text = $text4;
        break;
	case "time01";
        $text = $text4;
        break;
      case "time02";
        $text = $text4;
        break;
      case "time03";
        $text = $text4;
        break;
      case "time04";
	  $text = $text4;
        break;
      case "time05";
        $text = $text4;
        break;
      case "time06";
        $text = $text4;
        break;
	case "time07";
	  $text = $text4;
        break;
      case "time08";
        $text = $text4;
        break;
      case "time09";
        $text = $text4;
        break;
	case "time10";
	  $text = $text4;
        break;
      case "time11";
        $text = $text4;
        break;
      case "time12";
        $text = $text4;
        break;
	case "time13";
	  $text = $text4;
        break;
      case "time14";
        $text = $text4;
        break;
      case "time15";
        $text = $text4;
        break;
	case "time16";
	  $text = $text4;
        break;
      case "time17";
        $text = $text4;
        break;
      case "time18";
        $text = $text4;
        break;
	case "time19";
	  $text = $text4;
        break;
      case "time20";
        $text = $text4;
        break;
      case "time21";
        $text = $text4;
        break;
	case "time22";
	  $text = $text4;
        break;
      case "time23";
        $text = $text4;
        break;
      case "time24";
        $text = $text4;
        break;
	case "time25";
	  $text = $text4;
        break;
      case "time26";
        $text = $text4;
        break;
      case "time27";
        $text = $text4;
        break;
	case "time28";
	  $text = $text4;
        break;
      case "time29";
        $text = $text4;
        break;
      case "time30";
        $text = $text4;
        break;
	case "time31";
        $text = $text4;
        break;
    }
    break;
  	case "اختصاصی":
    switch ($time) {
      case "time00";
        $text = $text5_time0;
        break;
      case "time01";
        $text = $text5_time1;
        break;
      case "time02";
        $text = $text5_time2;
        break;
      case "time03";
        $text = $text5_time3;
        break;
      case "time04";
	  	$text = $text5_time4;
        break;
      case "time05";
        $text = $text5_time5;
        break;
      case "time06";
        $text = $text5_time6;
        break;
	case "time07";
	  $text = $text5_time7;
        break;
      case "time08";
        $text = $text5_time8;
        break;
      case "time09";
        $text = $text5_time9;
        break;
	case "time10";
	  $text = $text5_time10;
        break;
      case "time11";
        $text = $text5_time11;
        break;
      case "time12";
        $text = $text5_time12;
        break;
	case "time13";
	  $text = $text5_time13;
        break;
      case "time14";
        $text = $text5_time14;
        break;
      case "time15";
        $text = $text5_time15;
        break;
	case "time16";
	  $text = $text5_time16;
        break;
      case "time17";
        $text = $text5_time17;
        break;
      case "time18";
        $text = $text5_time18;
        break;
	case "time19";
	  $text = $text5_time19;
        break;
      case "time20";
        $text = $text5_time20;
        break;
      case "time21";
        $text = $text5_time21;
        break;
	case "time22";
	  $text = $text5_time22;
        break;
      case "time23";
        $text = $text5_time23;
        break;
      case "time24";
        $text = $text5_time24;
        break;
	case "time25";
	  $text = $text5_time25;
        break;
      case "time26";
        $text = $text5_time26;
        break;
      case "time27";
        $text = $text5_time27;
        break;
	case "time28";
	  $text = $text5_time28;
        break;
      case "time29";
        $text = $text5_time29;
        break;
      case "time30";
        $text = $text5_time30;
        break;
	case "time31";
        $text = $text5_time31;
        break;
    }
    break;            
                
}

$subfolder = "sub"; // نام پوشه فرعی

// بررسی وجود پوشه فرعی
if (!file_exists($subfolder)) {
  mkdir($subfolder, 0777, true);
}

// اضافه کردن نام پوشه فرعی به مسیر فایل
$filepath = $subfolder . "/" . $name;
// نام فایل را با پسوند .php مشخص کنید
$filename = $filepath . ".php";
// فایل را با حالت "نوشتن" باز کنید
$myfile = fopen($filename, "w");
// محتوای فایل را بنویسید
fwrite($myfile, $text);
// فایل را ببندید
fclose($myfile);





// ایجاد اتصال به دیتابیس
$conn = new mysqli($servername, $username, $password, $dbname);

//$stmt = "UPDATE customers SET operator = '$operator', time = '$time', last_update = '$last_update_tehran' WHERE name = '$name'";
  $filter_status = 'inactive'; // مقدار پیش‌فرض برای filter_status را inactive قرار می‌دهیم

        if ($operator == 'همه' || $operator == 'ایرانسل' || $operator == 'همراه اول' || $operator == 'اختصاصی' || $operator == 'فرگمنت') {
            $filter_status = 'active';
        } else {
            if ($operator == 'غیر فعال') {
            $filter_status = 'inactive';
            } else {
        // در اینجا می‌توانید یک مقدار پیش‌فرض یا عملیاتی برای سایر حالات انجام دهید
                $filter_status = 'null'; // مثلاً اگر هیچ یک از شرایط برقرار نباشد، مقدار "unknown" را به filter_status اختصاص می‌دهیم
            }
        }

$stmt = "UPDATE customers SET 
    operator = '$operator', 
    time = '$time', 
    last_update = '$last_update_tehran', 
    filter_status = '$filter_status'
WHERE name = '$name'";
        $conn->query($stmt);


}



// بستن اتصال به دیتابیس
$conn->close();

//// ذخیره تاریخچه تغییرات
    // ایجاد اتصال
    $conn2 = new mysqli($servername, $username, $password, $dbname);
    
    // آماده سازی و اجرای کوئری
    $sql2 = "INSERT INTO history (name, operator, change_time)
            VALUES (?, ?, ?)";
    $stmt2 = $conn2->prepare($sql2);
    $stmt2->bind_param("sss", $name, $operator, $last_update_tehran);
    $stmt2->execute();

    $stmt2->close();
    $conn2->close();

	
// پیغام موفقیت آمیز
  echo "<script>";
  //echo "alert('اطلاعات کاربر " . $name . " با موفقیت ذخیره شد');";
  echo "window.location.href = 'user.php?name=" . $name . "';";
  echo "</script>";

?>

                
                
