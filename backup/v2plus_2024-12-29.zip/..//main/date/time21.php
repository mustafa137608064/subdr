<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <!-- عنوان صفحه  -->
    <title>دریافت مقادیر تاریخ</title>
    <link rel="stylesheet" href="https://cdn.rawgit.com/rastikerdar/vazir-font/v22.1.0/dist/font-face.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
font-family: 'Vazir', sans-serif;margin: 0;display: flex;align-items: center;justify-content: center;height: 100vh;background: linear-gradient(to right, #f94e60, #f94e60, #f94e60, #f94e60); }
.container {text-align: center;padding: 20px;border: 2px solid #fff;border-radius: 15px;background-color: #f0f0f0;box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);max-width: 400px;width: 70%;}
.logo {border: none; background-color: transparent; border-radius: 50%; overflow: hidden;}
h1 {color: #494f4b; font-size: 36px;margin-bottom: 10px;}
.buttons {margin-top: 20px;}
.button {box-sizing: border-box;display: flex;align-items: center;justify-content: center;position: relative;width: 100%;padding: 18px 25px;margin: 10px 0;font-size: 18px;text-align: center;text-decoration: none;outline: none;background-color: #f94e60 ;color: #fff;border: 1px solid red;border-radius: 8px;cursor: pointer;transition: background-color 0.3s;overflow: hidden;}
.button:hover {background-color: red;}
.button::before {content: '';position: absolute;top: 0;left: -10px;width: 10px;height: 100%;background-color: red;border-top-left-radius: 8px;border-bottom-left-radius: 8px;transition: left 0.3s;}
.button:hover::before {left: 100%;}
.button i {display: flex;align-items: center;margin-left: 10px;}
.button.right-icon i,
.button.left-icon i {margin-left: 5px;position: absolute;top: 50%;transform: translateY(-50%);}
.button.right-icon i {left: auto;right: 25px;}
.button.left-icon i {left: auto;right: 25px;}
.button.right-icon i {margin-left: 3px;}
.fab.fa-telegram-plane:before { content: "\f3fe"; }
.fab.fa-list:before { content: "\f155"; }
.fab.fa-instagram:before { content: "\f16d"; }
 @media (max-width: 600px) {
.container {max-width: 90%;width: 300px;}
h1 {font-size: 20px;}
.button {padding: 12px 25px;font-size: 14px;padding-left: 2mm;padding-right: 25px;box-sizing: border-box;}
.button i {margin-left: 8px;}
.button.right-icon i {right: 75px;}
.server {background-color: lightblue;border-radius: 25px;padding: 15px;border: 1px solid blue;margin-top: 15px;text-align: center;}
.updateservers {background-color: green;color: white;border-radius: 25px;padding: 15px;border: 1px solid white;text-align: center;}                
</style>
</head>
<body>
    <div class="container">               
        <div class="buttons">
                  <span style="font-size: 18px; color: #666;">روز </span>
			<span style="font-size: 25px; color: #f94e60;">21</span>
			<span style="font-size: 18px; color: #666;"> ام </span>   
                <br><form style="text-align:center;border:2px solid #f94e60;border-radius:15px;">
                    <h3 style="font-size: 15px; color: #666;">:تاریخ ذخیره شده کنونی</h3>    
                <h3 style="font-size: 12px; color: #666;"><?php
				// نام فایل text.txt را اینجا وارد کنید
				$filename = "out/21";
				// خط مورد نظر را از فایل بخوانید
				$line = file_get_contents($filename);
				// موقعیت شروع و پایان بخش دلخواه را مشخص کنید
				$start = 196; // کاراکتر شروع کننده
                $end = 270; // کاراکتر پایان دهنده
				// بخش دلخواه را از خط استخراج کنید
				$sub_string = substr($line, $start, $end - $start + 1);
				// بخش دلخواه را نمایش دهید
				echo $sub_string;
				?></h3>
                <h3>
                <?php
				// اطلاعات اتصال به پایگاه داده
				include '../config.php';
				// ایجاد اتصال
				$conn = new mysqli($servername, $username, $password, $dbname);
				// نوشتن پرس و جو
				$sql = "SELECT day, month, year FROM times WHERE timename = 'time21'";
				// اجرای پرس و جو
				$result = $conn->query($sql);
				// اگر رکوردی یافت شد
				if ($result->num_rows > 0) {
 				// دریافت اطلاعات هر سطر
  				while ($row = $result->fetch_assoc()) {
    				echo "<span style='font-size: 12px; color: #666;'>تاریخ ثبت شده فعلی: </span>";
                    echo "<span style='font-size: 12px; color: #666;'>" . $row["day"] . "</span>";
    				echo "<span style='font-size: 12px; color: #666;'>-" . $row["month"] . "</span>";
    				echo "<span style='font-size: 12px; color: #666;'>-" . $row["year"] ."</span>";
                   
 				 }
				}
				// بستن اتصال
				$conn->close();
				?>
                </h3>
				</form>
               <h3 style="font-size: 15px; color: #666;">:مقادیر تاریخ جدید را وارد کنید</h3>
  <form action="updatetimes.php" method="post" style="direction:rtl;">
     <label for="timename">نام:</label>
  	<input type="text" id="timename" name="timename" value="time21" style="background-color:white;border-radius:25px;padding:10px;border:1px solid #f94e60;margin-top:15px;text-align:center;width:80%;" readonly>
     <br>      
	<label for="day">روز:</label>
    <input placeholder="1 تا 30 ..." style="background-color:white;border-radius:25px;padding:10px;border:1px solid #f94e60;margin-top:15px;text-align:center;width:80%;" type="number" id="day" name="day" min="1" max="31">
    <br>
    <label for="month">ماه:</label>
    <input placeholder="1 تا 12 ..." style="background-color:white;border-radius:25px;padding:10px;border:1px solid #f94e60;margin-top:15px;text-align:center;width:80%;" type="number" id="month" name="month" min="1" max="12">
    <br>
    <label for="year">سال:</label>
    <input placeholder="از 2024 ..." style="background-color:white;border-radius:25px;padding:10px;border:1px solid #f94e60;margin-top:15px;text-align:center;width:80%;" type="number" id="year" name="year" min="2023">
    <button style="background-color: green;color: white;border-radius: 25px;padding: 15px;border: 1px solid white;margin-top: 25px;text-align: center;" type="submit">ثبت تاریخ</button>
  </form>
                        </div>
              </div>
       <!---تولبار پایین صفحه---> 
   <div class="toolbar" style="position: fixed;bottom: 0;left: 0;width: 100%;height: 70px;background-color: #f94e60;display: flex;justify-content: space-around;align-items: center;border-top-left-radius: 50px;border-top-right-radius: 50px;border: 2px solid white;direction: rtl;">
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='../customers.php'"><i class="fa fa-book"></i></button>
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='../index.php'"><i class="fa fa-home"></i></button>
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='../profile.php'"><i class="fa fa-user"></i></button>
  </div>                
</body>
</html>

<div style="display:none;">
<?php 
include 'time00edit.php'; 
include 'time01edit.php'; 
include 'time02edit.php'; 
include 'time03edit.php'; 
include 'time04edit.php'; 
include 'time05edit.php'; 
include 'time06edit.php'; 
include 'time07edit.php'; 
include 'time08edit.php'; 
include 'time09edit.php'; 
include 'time10edit.php'; 
include 'time11edit.php'; 
include 'time12edit.php'; 
include 'time13edit.php'; 
include 'time14edit.php'; 
include 'time15edit.php'; 
include 'time16edit.php'; 
include 'time17edit.php'; 
include 'time18edit.php'; 
include 'time19edit.php'; 
include 'time20edit.php'; 
include 'time21edit.php'; 
include 'time22edit.php'; 
include 'time23edit.php'; 
include 'time24edit.php'; 
include 'time25edit.php'; 
include 'time26edit.php'; 
include 'time27edit.php'; 
include 'time28edit.php'; 
include 'time29edit.php'; 
include 'time30edit.php'; 
include 'time31edit.php'; 
?>
</div>