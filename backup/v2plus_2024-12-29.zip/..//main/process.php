<?php
session_start();

$loginusername = $_POST['loginusername'];
$loginpassword = $_POST['loginpassword'];

// اتصال به پایگاه داده
include 'config.php';
$db = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

// جستجوی اطلاعات کاربر
$sql = "SELECT * FROM users WHERE loginusername = ? AND loginpassword = ?";
$stmt = $db->prepare($sql);
$stmt->execute([$loginusername, $loginpassword]);

$user = $stmt->fetch();

if ($user) {
    // ذخیره اطلاعات کاربر در session
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['role'] = $user['role'];

    // هدایت کاربر به صفحه اصلی
    header('Location: index.php');
} else {
    // نمایش پیام خطا
     echo "<script>";
  	echo "alert('نام کاربری یا رمز عبور نامعتبر است!');";
  	echo "window.location.href = 'login.php';";
  	echo "</script>";
}
?>
