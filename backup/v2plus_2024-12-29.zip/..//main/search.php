<?php
session_start();



if (!isset($_SESSION['user_id'])) {

    header('Location: login.php');

    exit;

}


include 'config.php';

// ایجاد اتصال به دیتابیس
$conn = new mysqli($servername, $username, $password, $dbname);

// دریافت عبارت جستجو
$search = $_POST["search"];

// جستجو در دیتابیس
$sql = "SELECT name, operator, time, note FROM customers WHERE name LIKE '%$search%'";
$result = $conn->query($sql);


?>



<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- عنوان صفحه  -->
    <title>جستجو</title>
    <link rel="stylesheet" href="https://cdn.rawgit.com/rastikerdar/vazir-font/v22.1.0/dist/font-face.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
   </head>
<body>
    <div class="container">
            
            
                <div style="direction:rtl;background-color: #f0f0f0;display:inline-block;flex-direction:row;padding:10px;">
           
         <!-- دکمه‌های جستجو مشتری -->
    <form action="search.php" method="post" style="display: inline-block; flex-direction: row;">
            <label for="time">🔍:</label>
 	 <input class="navbarinput" type="text" name="search" placeholder="نام مشتری را وارد کنید">
     <input class="navbarbutton" type="submit" value="جستجو🔎" >
	</form>
     <!-- دکمه‌های تربیت بندی مشتری -->
        <form action="filter.php" method="post" style="display: inline-block; flex-direction: row;">
        <label for="time">🎰:</label>
        <select class="navbarinput" name="time" id="time">
            <option value="time00">♾️</option>
            <option value="time01">روز 1 ام</option>
            <option value="time02">روز 2 ام</option>
            <option value="time03">روز 3 ام</option>
            <option value="time04">روز 4 ام</option>
            <option value="time05">روز 5 ام</option>
            <option value="time06">روز 6 ام</option>
            <option value="time07">روز 7 ام</option>
            <option value="time08">روز 8 ام</option>
            <option value="time09">روز 9 ام</option>
            <option value="time10">روز 10 ام</option>
            <option value="time11">روز 11 ام</option>
            <option value="time12">روز 12 ام</option>
            <option value="time13">روز 13 ام</option>
            <option value="time14">روز 14 ام</option>
            <option value="time15">روز 15 ام</option>
            <option value="time16">روز 16 ام</option>
            <option value="time17">روز 17 ام</option>
            <option value="time18">روز 18 ام</option>
            <option value="time19">روز 19 ام</option>
            <option value="time20">روز 20 ام</option>
            <option value="time21">روز 21 ام</option>
            <option value="time22">روز 22 ام</option>
            <option value="time23">روز 23 ام</option>
            <option value="time24">روز 24 ام</option>
            <option value="time25">روز 25 ام</option>
            <option value="time26">روز 26 ام</option>
            <option value="time27">روز 27 ام</option>
            <option value="time28">روز 28 ام</option>
            <option value="time29">روز 29 ام</option>
            <option value="time30">روز 30 ام</option>
            <option value="time31">روز 31 ام</option>
        </select>
        <input class="navbarbutton" type="submit" value="نمایش🎰">
    	</form>
                <div style="border :2px solid #f04e60;"></div>  
  </div>
            
            
                   <?php
            echo "<link rel='stylesheet' href='style.css'>";
  // نمایش اطلاعات مشتریان
if ($result->num_rows > 0) {
        
  	echo "<table style='width: 80vw;margin: 0 auto;text-align:center;'>";
        $isFirstRow = true;
    	$counter = 1;
    while($row = $result->fetch_assoc()) {
                if ($isFirstRow) {
       echo "<tr>";
        // نمایش عناوین ستون ها فقط در سطر اول
        echo "<th>ردیف</th>";
        echo "<th>نام مشتری</th>"; 
        echo "<th>جزئیات</th>"; 
        echo "<th>وضعیت</th>";                 
        echo "</tr>";
        $isFirstRow = false;
    }

    
    // نمایش شماره
    echo "<th style='border-bottom:1px solid red;'>" . $counter . "</th>";
    $counter++; // افزایش مقدار شمارنده در هر سطر
	// نمایش نام ها
 	echo "<th style='border-bottom:1px solid red;'><h5>" . $row['name'] . "</h5></th>";
    //نمایش جزییات 
    echo "<th style='border-bottom:1px solid red;'><a style='text-decoration:none; color:white;background-color:#f94e60;padding:5px;border-radius:15px;border:1px solid white;' href='user.php?name=" . $row['name'] . "'>➕</a></th><br>";        
	//نمایش وضعیت
    echo "<th style='border-bottom:1px solid red;'><h5>" . $row['operator'] . "</h5></th>";
    
    echo "</tr>";

    $counter++;
  	} 
  	echo "</table>";
        echo "<br><br><br><br><br><br><br>"; 
	} else {
  	echo "هیچ مشتری در دیتابیس وجود ندارد.";
}
?>
          


         
  </div>
        
           
       <!---تولبار پایین صفحه---> 
   <div class="toolbar" style="position: fixed;bottom: 0;left: 0;width: 100%;height: 70px;background-color: #f94e60;display: flex;justify-content: space-around;align-items: center;border-top-left-radius: 50px;border-top-right-radius: 50px;border: 2px solid white;direction: rtl;">
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='customers.php'"><i class="fa fa-book"></i></button>
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='index.php'"><i class="fa fa-home"></i></button>
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='profile.php'"><i class="fa fa-user"></i></button>
  </div>      
        
                        
</body>
</html>
<?php



// بستن اتصال به دیتابیس

$conn->close();

?>