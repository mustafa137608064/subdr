<?php
include 'config.php';

// دریافت اطلاعات از فرم
$page_name = $_POST['page_name'];
$allowed_ip = $_POST['allowed_ip'];

// اتصال به پایگاه داده
$db_connection = mysqli_connect($servername, $username, $password, $dbname);

// ذخیره IP مجاز در پایگاه داده
$sql_query = "UPDATE `ip_addresses` SET `allow_ip` = '$allowed_ip' WHERE `page_name` = '$page_name'";
mysqli_query($db_connection, $sql_query);

// بستن اتصال به پایگاه داده
mysqli_close($db_connection);


// پیغام موفقیت آمیز
  echo "<script>";
  echo "alert('" . $allowed_ip . " بعنوان مجاز برای " . $page_name . " ثبت شد');";
  echo "window.location.href = 'user.php?name=" . $page_name . "';";
  echo "</script>";
?>
