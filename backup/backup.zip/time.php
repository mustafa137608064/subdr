<?php
session_start();



if (!isset($_SESSION['user_id'])) {

    header('Location: login.php');

    exit;

}

//// تعیین و نمایش زمان باقی مانده اتمام حجم و مدت سرویس مشترکین

$date00 = "./date/out/00";
$time00 = file_get_contents($date00);
$date01 = "./date/out/01";
$time01 = file_get_contents($date01);
$date02 = "./date/out/02";
$time02 = file_get_contents($date02);
$date03 = "./date/out/03";
$time03 = file_get_contents($date03);
$date04 = "./date/out/04";
$time04 = file_get_contents($date04);
$date05 = "./date/out/05";
$time05 = file_get_contents($date05);
$date06 = "./date/out/06";
$time06 = file_get_contents($date06);
$date07 = "./date/out/07";
$time07 = file_get_contents($date07);
$date08 = "./date/out/08";
$time08 = file_get_contents($date08);
$date09 = "./date/out/09";
$time09 = file_get_contents($date09);
$date10 = "./date/out/10";
$time10 = file_get_contents($date10);
$date11 = "./date/out/11";
$time11 = file_get_contents($date11);
$date12 = "./date/out/12";
$time12 = file_get_contents($date12);
$date13 = "./date/out/13";
$time13 = file_get_contents($date13);
$date14 = "./date/out/14";
$time14 = file_get_contents($date14);
$date15 = "./date/out/15";
$time15 = file_get_contents($date15);
$date16 = "./date/out/16";
$time16 = file_get_contents($date16);
$date17 = "./date/out/17";
$time17 = file_get_contents($date17);
$date18 = "./date/out/18";
$time18 = file_get_contents($date18);
$date19 = "./date/out/19";
$time19 = file_get_contents($date19);
$date20 = "./date/out/20";
$time20 = file_get_contents($date20);
$date21 = "./date/out/21";
$time21 = file_get_contents($date21);
$date22 = "./date/out/22";
$time22 = file_get_contents($date22);
$date23 = "./date/out/23";
$time23 = file_get_contents($date23);
$date24 = "./date/out/24";
$time24 = file_get_contents($date24);
$date25 = "./date/out/25";
$time25 = file_get_contents($date25);
$date26 = "./date/out/26";
$time26 = file_get_contents($date26);
$date27 = "./date/out/27";
$time27 = file_get_contents($date27);
$date28 = "./date/out/28";
$time28 = file_get_contents($date28);
$date29 = "./date/out/29";
$time29 = file_get_contents($date29);
$date30 = "./date/out/30";
$time30 = file_get_contents($date30);
$date31 = "./date/out/31";
$time31 = file_get_contents($date31);

?>