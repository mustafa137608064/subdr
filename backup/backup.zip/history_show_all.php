<?php
include 'config.php';
session_start();



if (!isset($_SESSION['user_id'])) {

    header('Location: login.php');

    exit;

}

?>
<html>
        <div style="display:none;">
        <?php
					include 'refresh.php';     
				?>
         </div>
</html>
<?php

// ایجاد اتصال به دیتابیس
$conn = new mysqli($servername, $username, $password, $dbname);
// دریافت نام و نوع شبکه مشتریان از دیتابیس
$sql = "SELECT name, operator, change_time FROM history";
$result = $conn->query($sql);
// دریافت تمام نام های مشتریان
$stmt = $conn->query("SELECT name FROM history");
$names = $stmt->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- عنوان صفحه  -->
    <title>تاریخچه تغییرات</title>
    <link rel="stylesheet" href="https://cdn.rawgit.com/rastikerdar/vazir-font/v22.1.0/dist/font-face.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

   </head>
<body>
    <div class="container">
           
                <div style="direction:rtl;background-color: #f0f0f0;display:inline-block;flex-direction:row;padding:10px;">
                <!-- دکمه‌های ساخت مشتری -->
	
         <!-- دکمه‌های جستجو مشتری -->
    <form action="search.php" method="post" style="display: inline-block; flex-direction: row;">
            <label for="time">🔍:</label>
 	 <input class="navbarinput" type="text" name="search" placeholder="نام مشتری را وارد کنید">
     <input class="navbarbutton" type="submit" value="جستجو🔎" >
	</form>
                <div style="border :2px solid #f04e60;"></div>    
        
  </div>
           
<?php
echo "<link rel='stylesheet' href='style.css'>";
// نمایش اطلاعات مشتریان                        
// کوئری برای شمارش کل رکوردها
$result_total = mysqli_query($conn, "SELECT COUNT(*) as total FROM history");
$row_total = mysqli_fetch_assoc($result_total);
$total_records = $row_total['total'];
// تنظیمات صفحه بندی
$resultsPerPage = 10; // تعداد رکورد در هر صفحه
$currentPage = isset($_GET['page']) ? $_GET['page'] : 1; // شماره صفحه جاری
$offset = ($currentPage - 1) * $resultsPerPage;
// کوئری اصلی با محدودیت
$result = mysqli_query($conn, "SELECT * FROM history ORDER BY change_time DESC LIMIT $offset, $resultsPerPage");
if ($result->num_rows > 0) {
    echo "<table style='width: 80vw;margin: 0 auto;text-align:center;'>";
    $counter = 1; // تعریف و مقداردهی اولیه متغیر شمارنده
    echo "<thead>";
    // سرفصل‌های جدول (نام ستون‌ها)
    echo "<tr>";
    echo "<th style='font-size:14px;'>ردیف</th>";
    echo "<th style='font-size:14px;'>نام مشتری</th>";
    echo "<th style='font-size:14px;'>جزئیات</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        // نمایش داده‌های هر ردیف
        echo "<td style='border-bottom:1px solid red;font-size:12px;'>" . $counter . "</td>";
        echo "<td style='border-bottom:1px solid red;'><a style='font-size:12px;text-decoration:none; color:white;background-color:#f94e60;padding:5px;border-radius:15px;border:1px solid white;' href='user.php?name=" . $row['name'] . "'>" . $row['name'] . "</a></td>";
        echo "<td style='border-bottom:1px solid red;'><h4 style='font-size:12px;'>" . $row['change_time'] . "</h4></td>";
        echo "</tr>";
        $counter++;
    }
    echo "</tbody>";
    echo "</table>";
}
// ایجاد لینک‌های صفحات
$totalPages = ceil($total_records / $resultsPerPage);
echo "<div class='pagination' style='margin:25px;margin-bottom:70px;'>";
for ($i = 1; $i <= $totalPages; $i++) {
    if ($i <= 3 || $i > $totalPages - 3) {
        echo "<a style='text-decoration:none; color:white;background-color:#f94e60;padding:5px;border-radius:15px;border:1px solid white;' href='?page=$i'>" . $i . "</a> ";
    } elseif ($i == 4) {
        echo "... ";}}
echo "</div>";
//echo "<br><br><br><br>";
// بستن اتصال
$conn->close();
?>

           
  </div>
          
       <!---تولبار پایین صفحه---> 
        
   <div class="toolbar" style="position: fixed;bottom: 0;left: 0;width: 100%;height: 70px;background-color: #f94e60;display: flex;justify-content: space-around;align-items: center;border-top-left-radius: 50px;border-top-right-radius: 50px;border: 2px solid white;direction: rtl;">
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='customers.php'"><i class="fa fa-book"></i></button>
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='index.php'"><i class="fa fa-home"></i></button>
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='profile.php'"><i class="fa fa-user"></i></button>
  </div>      
        
       
</body>
</html>


