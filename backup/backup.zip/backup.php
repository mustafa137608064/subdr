چ<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'github_config.php';
include 'config.php';

// تنظیمات گیت‌هاب
$githubUsername = 'mustafa137608064';
$repositoryName = 'subdr';
$folderName = 'backup';
$personalAccessToken = $github_token;

// فایل بکاپ دیتابیس
$databaseBackupFile = __DIR__ . DIRECTORY_SEPARATOR . 'database_backup.sql';

// مسیر فایل زیپ
$zipFileName = __DIR__ . DIRECTORY_SEPARATOR . 'backup.zip';

// تابع برای بکاپ گرفتن از دیتابیس
function createDatabaseBackup($backupFile, $servername, $username, $password, $dbname) {
    $connection = new mysqli($servername, $username, $password, $dbname);

    if ($connection->connect_error) {
        die("خطا در اتصال به دیتابیس: " . $connection->connect_error);
    }

    $tables = [];
    $result = $connection->query("SHOW TABLES");
    while ($row = $result->fetch_row()) {
        $tables[] = $row[0];
    }

    $sqlDump = "-- Database Backup\n-- Generated on: " . date('Y-m-d H:i:s') . "\n\n";

    foreach ($tables as $table) {
        $createTable = $connection->query("SHOW CREATE TABLE `$table`")->fetch_row();
        $sqlDump .= $createTable[1] . ";\n\n";

        $result = $connection->query("SELECT * FROM `$table`");
        while ($row = $result->fetch_assoc()) {
            $sqlDump .= "INSERT INTO `$table` VALUES(";
            foreach ($row as $value) {
                $sqlDump .= "'" . $connection->real_escape_string($value) . "',";
            }
            $sqlDump = rtrim($sqlDump, ',') . ");\n";
        }
        $sqlDump .= "\n";
    }

    if (file_put_contents($backupFile, $sqlDump)) {
        echo "بکاپ دیتابیس با موفقیت ایجاد شد: $backupFile\n";
    } else {
        echo "خطا در ذخیره فایل بکاپ.\n";
        return false;
    }

    $connection->close();
    return true;
}

// ایجاد بکاپ دیتابیس
if (!createDatabaseBackup($databaseBackupFile, $servername, $username, $password, $dbname)) {
    die("خطا در ایجاد بکاپ از دیتابیس.");
}

// تابع برای فشرده‌سازی پوشه
function createZip($source, $destination, $additionalFiles = []) {
    if (!extension_loaded('zip') || !file_exists($source)) {
        return false;
    }

    $zip = new ZipArchive();
    if (!$zip->open($destination, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
        return false;
    }

    $source = realpath($source);
    if (is_dir($source)) {
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($source),
            RecursiveIteratorIterator::LEAVES_ONLY
        );

        foreach ($files as $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = substr($filePath, strlen($source) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }
    } else {
        $zip->addFile($source, basename($source));
    }

    // اضافه کردن فایل‌های اضافی
    foreach ($additionalFiles as $file) {
        if (file_exists($file)) {
            $zip->addFile($file, basename($file));
        }
    }

    return $zip->close();
}


// فشرده‌سازی فایل‌ها
if (!createZip(__DIR__, $zipFileName, [$databaseBackupFile])) {
    die("خطا در ایجاد فایل زیپ.");
}

// تابع برای آپلود فایل زیپ به گیت‌هاب
function uploadFileToGitHub($filePath, $githubUsername, $repositoryName, $folderName, $personalAccessToken) {
    $fileContent = file_get_contents($filePath);
    $base64Content = base64_encode($fileContent);
    $fileName = basename($filePath);

    $url = "https://api.github.com/repos/$githubUsername/$repositoryName/contents/$folderName/$fileName";

    $data = [
        'message' => "Upload $fileName",
        'content' => $base64Content
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: token ' . $personalAccessToken,
        'User-Agent: PHP Script'
    ]);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return $httpCode === 201;
}

// آپلود فایل زیپ به گیت‌هاب
if (uploadFileToGitHub($zipFileName, $githubUsername, $repositoryName, $folderName, $personalAccessToken)) {
    echo "فایل زیپ با موفقیت آپلود شد.";
} else {
    echo "خطا در آپلود فایل زیپ.";
}

// حذف فایل‌های موقت
unlink($zipFileName);
unlink($databaseBackupFile);

?>
