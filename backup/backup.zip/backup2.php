<?php


include 'config.php';

// نام فایل فشرده
$backup_file = "v2plus_" . date("Y-m-d") . ".zip";

// اتصال به پایگاه داده
$db = new mysqli($servername, $username, $password, $dbname);

// بررسی اتصال
if ($db->connect_error) {
    die("خطا در اتصال به پایگاه داده: " . $db->connect_error);
}

// تهیه لیست از تمام فایل ها
$files = array();
$dir = "../../https://puzzle.social-networking.me";
$recursive = true;

// تابع بازگشتی برای پیمایش در دایرکتوری ها
function get_files($dir, $recursive) {
    global $files;

    $handle = opendir($dir);
    while (($file = readdir($handle)) !== false) {
        if ($file != "." && $file != "..") {
            $path = $dir . "/" . $file;
            if (is_dir($path) && $recursive) {
                get_files($path, $recursive);
            } else {
                $files[] = $path;
            }
        }
    }
    closedir($handle);
}

// دریافت لیست تمام فایل ها
get_files($dir, $recursive);

// تهیه نسخه پشتیبان از پایگاه داده
$dump = "";
$tables = array();
$result = $db->query("SHOW TABLES");
while ($row = $result->fetch_assoc()) {
    $tables[] = $row["Tables_in_" . $dbname];
}

foreach ($tables as $table) {
    $dump .= "DROP TABLE IF EXISTS `" . $table . "`;\n";
    $result = $db->query("SHOW CREATE TABLE `" . $table . "`");
    $row = $result->fetch_assoc();
    $dump .= $row["Create Table"] . ";\n\n";

    $result = $db->query("SELECT * FROM `" . $table . "`");
    while ($row = $result->fetch_assoc()) {
        $dump .= "INSERT INTO `" . $table . "` (`" . implode("`, `", array_keys($row)) . "`) VALUES ('" . implode("', '", array_values($row)) . "');\n";
    }
}

// فشرده سازی فایل ها و دیتابیس
$zip = new ZipArchive();
$zip->open($backup_file, ZipArchive::CREATE);
foreach ($files as $file) {
    $zip->addFile($file, $file);
}
$zip->addFromString("database.sql", $dump);
$zip->close();

// ارسال فایل فشرده به مرورگر
header('Content-Type: application/zip');
header('Content-Length: ' . filesize($backup_file));
header('Content-Disposition: attachment; filename="' . $backup_file . '"');
readfile($backup_file);

// حذف فایل فشرده از سرور
unlink($backup_file);

?>
