<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'config.php';

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST["name"]) && !empty(trim($_POST["name"]))) {
    $name = trim($_POST["name"]);

    // دریافت بیشترین مقدار counting
    // گام اول: دریافت بیشترین مقدار counting
    $result = $conn->query("SELECT IFNULL(MAX(counting), 100) + 1 AS next_count FROM customers WHERE counting >= 100");
    $row = $result->fetch_assoc();
    $next_count = $row['next_count'];

    // گام دوم: وارد کردن داده‌ها با counting جدید
    $stmt = $conn->prepare("INSERT INTO customers (name, counting) VALUES (?, ?)");
    $stmt->bind_param("si", $name, $next_count);  // "s" برای رشته (name)، "i" برای عدد صحیح (next_count)
    
    // فقط یک بار execute را فراخوانی کنید
    if ($stmt->execute()) {
        echo "<script>";
        echo "window.location.href = 'user.php?name=" . urlencode($name) . "';";
        echo "</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Invalid input. Name cannot be empty.";
}

$conn->close();
?>
