<?php
session_start();



if (!isset($_SESSION['user_id'])) {

    header('Location: login.php');

    exit;

}


include 'config.php';

    

    // اتصال به پایگاه داده
    $conn = new mysqli($servername, $username, $password, $dbname);



        
        $sql = "SELECT * FROM customers WHERE operator = 'همراه اول'";
    // اجرای کوئری و دریافت نتایج
    $result = $conn->query($sql);
?>




<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- عنوان صفحه  -->
    <title>لیست مشتری های همراه اول</title>
    <link rel="stylesheet" href="https://cdn.rawgit.com/rastikerdar/vazir-font/v22.1.0/dist/font-face.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
   </head>
<body>
    <div class="container">
            <div style="border-radius: 15px;border:2px solid #f94e60;padding:10px;">
             <span style="font-size: 12px; color: #666;">لیست تمامی مشتریان</span>
            <span style="font-size: 18px; color: #f94e60;">همراه اول</span>
            </div>
               
              <?php
            echo "<link rel='stylesheet' href='style.css'>";
  // نمایش اطلاعات مشتریان
if ($result->num_rows > 0) {
        
  	echo "<table style='width: 80vw;margin: 0 auto;text-align:center;'>";
        $isFirstRow = true;
    	$counter = 1;
    while($row = $result->fetch_assoc()) {
                if ($isFirstRow) {
        echo "<tr>";
        // نمایش عناوین ستون ها فقط در سطر اول
        echo "<th>ردیف</th>";
        echo "<th>نام مشتری</th>"; 
        echo "<th>جزئیات</th>";  
        echo "</tr>";
        $isFirstRow = false;
    }

    
    // نمایش شماره
    echo "<th style='border-bottom:1px solid red;'>" . $counter . "</th>";
    $counter++; // افزایش مقدار شمارنده در هر سطر
	// نمایش نام ها
 	echo "<th style='border-bottom:1px solid red;'><h4>" . $row['name'] . "</h4></th>";
    echo "<th style='border-bottom:1px solid red;'><a style='text-decoration:none; color:white;background-color:#f94e60;padding:5px;border-radius:15px;border:1px solid white;' href='user.php?name=" . $row['name'] . "'>➕</a><th><br>";        
		

    echo "</tr>";

    $counter++;
  	} 
  	echo "</table>";
        echo "<br><br><br><br><br><br><br>"; 
	} else {
  	echo "هیچ مشتری در دیتابیس وجود ندارد.";
}
?>
            
  


         
  </div>
                 
        
           
       <!---تولبار پایین صفحه---> 
   <div class="toolbar" style="position: fixed;bottom: 0;left: 0;width: 100%;height: 70px;background-color: #f94e60;display: flex;justify-content: space-around;align-items: center;border-top-left-radius: 50px;border-top-right-radius: 50px;border: 2px solid white;direction: rtl;">
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='customers.php'"><i class="fa fa-book"></i></button>
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='index.php'"><i class="fa fa-home"></i></button>
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='profile.php'"><i class="fa fa-user"></i></button>
  </div>      
        
</body>
</html>


<?php
$conn->query($sql);

// بستن اتصال به دیتابیس
$conn->close();

?>
