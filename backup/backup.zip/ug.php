<?php
include 'github_config.php';
$githubUsername = 'mustafa137608064';
$repositoryName = 'subdr';
$folderName = 'users';
$personalAccessToken = $github_token;
$localFolder = 'sub';

// تابع برای فهرست کردن فایل‌های موجود در پوشه
function listFilesInFolder($githubUsername, $repositoryName, $folderName, $personalAccessToken) {
    $url = "https://api.github.com/repos/$githubUsername/$repositoryName/contents/$folderName";
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: token ' . $personalAccessToken,
        'User-Agent: PHP Script'
    ]);
    $response = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($response, true);
    if (is_array($data)) {
        return $data;
    }
    return [];
}

// تابع برای حذف فایل از مخزن
function deleteFileFromGitHub($filePath, $sha, $githubUsername, $repositoryName, $personalAccessToken) {
    $url = "https://api.github.com/repos/$githubUsername/$repositoryName/contents/$filePath";
    $data = [
        'message' => "Delete $filePath",
        'sha' => $sha
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: token ' . $personalAccessToken,
        'User-Agent: PHP Script'
    ]);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return $httpCode === 200;
}

// تابع برای آپلود فایل در گیت‌هاب
function uploadFileToGitHub($filePath, $githubUsername, $repositoryName, $folderName, $personalAccessToken) {
    $fileContent = file_get_contents($filePath);
    $base64Content = base64_encode($fileContent);
    $fileName = basename($filePath);

    $url = "https://api.github.com/repos/$githubUsername/$repositoryName/contents/$folderName/$fileName";

    $data = [
        'message' => "Upload $fileName",
        'content' => $base64Content
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: token ' . $personalAccessToken,
        'User-Agent: PHP Script'
    ]);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return $httpCode === 201;
}

// تابع برای حذف پوشه (در واقع حذف تمامی فایل‌های داخل آن)
function deleteFolderAndContents($githubUsername, $repositoryName, $folderName, $personalAccessToken) {
    $files = listFilesInFolder($githubUsername, $repositoryName, $folderName, $personalAccessToken);

    foreach ($files as $file) {
        if (isset($file['path']) && isset($file['sha'])) {
            deleteFileFromGitHub($file['path'], $file['sha'], $githubUsername, $repositoryName, $personalAccessToken);
        }
    }
}

// حذف پوشه users و محتویات آن
deleteFolderAndContents($githubUsername, $repositoryName, $folderName, $personalAccessToken);

// آپلود فایل‌ها
if (is_dir($localFolder)) {
    $files = scandir($localFolder);
    $successfulUploads = 0;
    $failedFiles = [];

    foreach ($files as $file) {
        if ($file !== '.' && $file !== '..') {
            $filePath = $localFolder . DIRECTORY_SEPARATOR . $file;
            if (is_file($filePath)) {
                $status = uploadFileToGitHub($filePath, $githubUsername, $repositoryName, $folderName, $personalAccessToken);
                if ($status) {
                    $successfulUploads++;
                } else {
                    $failedFiles[] = $file;
                }
            }
        }
    }

    echo "تعداد فایل‌های موفق آپلود شده: $successfulUploads<br>";
    echo "تعداد فایل‌های ناموفق: " . count($failedFiles) . "<br>";

    if (!empty($failedFiles)) {
        echo "اسامی فایل‌های ناموفق:<br>";
        foreach ($failedFiles as $failedFile) {
            echo "- $failedFile<br>";
        }
    }
} else {
    echo "پوشه $localFolder وجود ندارد.";
}
?>

<hr>
<h2>لینک به پوشه آپلود شده در گیت‌هاب:</h2>
<p><a 
href="https://github.com/<?php echo $githubUsername; ?>/<?php echo $repositoryName; ?>/tree/main/<?php echo $folderName; ?>" target="_blank">مشاهده پوشه در گیت‌هاب</a></p>
