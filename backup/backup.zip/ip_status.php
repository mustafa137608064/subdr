<?php

// دریافت نام و وضعیت از URL
$name = $_POST['name'];
$status = $_POST['status'];

// به روز رسانی وضعیت در پایگاه داده
$db = new PDO('mysql:host=fdb1031.runhosting.com;dbname=4428161_db', '4428161_db', 'mustafa1234');
$stmt = $db->prepare('UPDATE ip_addresses SET status = ? WHERE page_name = ?');
$stmt->execute([$status, $name]);

// نمایش وضعیت
// پیغام موفقیت آمیز
  echo "<script>";
  echo "alert('نوع کاربری برای " . $name . " با موفقیت تغییر کرد');";
  echo "window.location.href = 'user.php?name=" . $name . "';";
  echo "</script>";


?>
