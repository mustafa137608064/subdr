<?php
session_start();



if (!isset($_SESSION['user_id'])) {

    header('Location: login.php');

    exit;

}
include "config.php";
// اتصال به دیتابیس (با توجه به تنظیمات خودتان)
$conn = new mysqli($servername, $username, $password, $dbname);

// دریافت مقدار name از فرم
$name = $_POST['name'];

// دریافت وضعیت فعلی از دیتابیس
$sql = "SELECT filter_status FROM customers WHERE name = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "s", $name);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($result);
$current_status = $row['filter_status'];

// تغییر وضعیت و به‌روزرسانی دیتابیس
$new_status = ($current_status == 'active') ? 'inactive' : 'active';
$sql = "UPDATE customers SET filter_status = ? WHERE name = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ss", $new_status, $name);
mysqli_stmt_execute($stmt);

// هدایت مجدد به صفحه قبلی
header("Location: user.php?name=" . $name);
exit;
?>