<style>
                        .readmorebtn {font-size: 16px;font-weight: 800;background-color:none;color:#2565ae;border:2px solid #2565ae;box-sizing:border-box;font-size: 16px;margin: 20px;padding: 0 2rem;border-radius:15px;}      
                #more {display: none;}
                #more2 {display: none;}
                #more3 {display: none;}
                #more4 {display: none;}
                #more5 {display: none;}
        </style>

<button onclick="myFunction()" id="myBtn" class="readmorebtn">بخش اپراتور و زمانبندی➕</button>        

    <div id="div1">        

    <span id="dots" style="color:#f0f0f0;"></span><span id="more">        

    <!-- محتوا دلخواه اینجا قرار میگیرد -->
            
                </span></div>  
    <!-- اسکریپت مخفی سازی بخش های دلخواه -->
    <script>
    function myFunction() {
    var dots = document.getElementById("dots");
    var moreText = document.getElementById("more");
    var btnText = document.getElementById("myBtn");
    if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "بخش اپراتور و زمانبندی➕"; 
    moreText.style.display = "none";
    } else {
    dots.style.display = "none";
    btnText.innerHTML = "بخش اپراتور و زمانبندی➖"; 
    moreText.style.display = "inline";
    }
    }
    </script>