<?php
session_start();



if (!isset($_SESSION['user_id'])) {

    header('Location: login.php');

    exit;

}


include 'config.php';

// ایجاد اتصال به دیتابیس
$conn = new mysqli($servername, $username, $password, $dbname);

// دریافت نام جدید از فرم
$name = $_POST["name"];



if (empty($name)) {

  echo "<script>";

  echo "alert('خطا: نام کاربری خالی است.');";

  echo "window.location.href = 'customers.php';";

  echo "</script>";

  exit;

}

// نمایش پیغام تاییدیه
echo "<script>";
echo "var confirmDelete = confirm('آیا از حذف اطلاعات کاربر " . $name . " اطمینان دارید؟');";
echo "if (confirmDelete) {";
echo "window.location.href = 'delete_customer.php?name=" . $name . "';";
echo "} else {";

echo "window.location.href = 'user.php?name=" . $name . "';";
echo "}";
echo "</script>";

?>
