<?php
session_start();



if (!isset($_SESSION['user_id'])) {

    header('Location: login.php');

    exit;

}


include 'config.php';

// ایجاد اتصال به دیتابیس
$conn = new mysqli($servername, $username, $password, $dbname);

// دریافت نام کاربر از URL
$name = $_GET["name"];

// حذف فایل

unlink('sub/' . $name . '.php');

// حذف از دیتابیس
$sql = "DELETE FROM customers WHERE name = '$name'";

$conn->query($sql);

// پیغام موفقیت آمیز حذف کاربر

echo "<script>";

echo "alert('اطلاعات کاربر " . $name . " با موفقیت حذف شد.');";

echo "window.location.href = 'customers.php';";

echo "</script>";

?>
