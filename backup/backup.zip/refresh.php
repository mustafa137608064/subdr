<?php
session_start();



if (!isset($_SESSION['user_id'])) {

    header('Location: login.html');

    exit;

}

include 'config.php';

// ایجاد اتصال به دیتابیس
$conn = new mysqli($servername, $username, $password, $dbname);
// دریافت نام و نوع شبکه مشتریان از دیتابیس
$sql = "SELECT name, operator, time, note FROM customers";
$result = $conn->query($sql);



// بررسی اطلاعات هر مشتری
while ($row = $result->fetch_assoc()) {
  $name = $row["name"];
  $operator = $row["operator"];
  $time = $row["time"];
  $note = $row["note"];

  // تعیین متن بر اساس اپراتور و زمان
  $text = "";
  if ($operator === "ایرانسل") {
           if ($time === "time00") {
      $text = $text1_time0;
    } else if ($time === "time01") {
      $text = $text1_time1;
    } else if ($time === "time02") {
      $text = $text1_time2;
    } else if ($time === "time03") {
      $text = $text1_time3;
    } else if ($time === "time04") {
      $text = $text1_time4;
    } else if ($time === "time05") {
      $text = $text1_time5;
    } else if ($time === "time06") {
      $text = $text1_time6;
    } else if ($time === "time07") {
      $text = $text1_time7;
    } else if ($time === "time08") {
      $text = $text1_time8;
    } else if ($time === "time09") {
      $text = $text1_time9;
    }else if ($time === "time10") {
      $text = $text1_time10;
    } else if ($time === "time11") {
      $text = $text1_time11;
    } else if ($time === "time12") {
      $text = $text1_time12;
    } else if ($time === "time13") {
      $text = $text1_time13;
    }else if ($time === "time14") {
      $text = $text1_time14;
    } else if ($time === "time15") {
      $text = $text1_time15;
    } else if ($time === "time16") {
      $text = $text1_time16;
    } else if ($time === "time17") {
      $text = $text1_time17;
    } else if ($time === "time18") {
      $text = $text1_time18;
    } else if ($time === "time19") {
      $text = $text1_time19;
    } else if ($time === "time20") {
      $text = $text1_time20;
    } else if ($time === "time21") {
      $text = $text1_time21;
    }else if ($time === "time22") {
      $text = $text1_time22;
    } else if ($time === "time23") {
      $text = $text1_time23;
    } else if ($time === "time24") {
      $text = $text1_time24;
    } else if ($time === "time25") {
      $text = $text1_time25;
    }else if ($time === "time26") {
      $text = $text1_time26;
    } else if ($time === "time27") {
      $text = $text1_time27;
    } else if ($time === "time28") {
      $text = $text1_time28;
    } else if ($time === "time29") {
      $text = $text1_time29;
    }else if ($time === "time30") {
      $text = $text1_time30;
    } else if ($time === "time31") {
      $text = $text1_time31;
    }
  } else if ($operator === "همراه اول") {
           if ($time === "time00") {
      $text = $text2_time0;
    } else if ($time === "time01") {
      $text = $text2_time1;
    } else if ($time === "time02") {
      $text = $text2_time2;
    } else if ($time === "time03") {
      $text = $text2_time3;
    } else if ($time === "time04") {
      $text = $text2_time4;
    } else if ($time === "time05") {
      $text = $text2_time5;
    } else if ($time === "time06") {
      $text = $text2_time6;
    } else if ($time === "time07") {
      $text = $text2_time7;
    } else if ($time === "time08") {
      $text = $text2_time8;
    } else if ($time === "time09") {
      $text = $text2_time9;
    }else if ($time === "time10") {
      $text = $text2_time10;
    } else if ($time === "time11") {
      $text = $text2_time11;
    } else if ($time === "time12") {
      $text = $text2_time12;
    } else if ($time === "time13") {
      $text = $text2_time13;
    }else if ($time === "time14") {
      $text = $text2_time14;
    } else if ($time === "time15") {
      $text = $text2_time15;
    } else if ($time === "time16") {
      $text = $text2_time16;
    } else if ($time === "time17") {
      $text = $text2_time17;
    } else if ($time === "time18") {
      $text = $text2_time18;
    } else if ($time === "time19") {
      $text = $text2_time19;
    } else if ($time === "time20") {
      $text = $text2_time20;
    } else if ($time === "time21") {
      $text = $text2_time21;
    }else if ($time === "time22") {
      $text = $text2_time22;
    } else if ($time === "time23") {
      $text = $text2_time23;
    } else if ($time === "time24") {
      $text = $text2_time24;
    } else if ($time === "time25") {
      $text = $text2_time25;
    }else if ($time === "time26") {
      $text = $text2_time26;
    } else if ($time === "time27") {
      $text = $text2_time27;
    } else if ($time === "time28") {
      $text = $text2_time28;
    } else if ($time === "time29") {
      $text = $text2_time29;
    }else if ($time === "time30") {
      $text = $text2_time30;
    } else if ($time === "time31") {
      $text = $text2_time31;
    }
} else if ($operator === "غیر فعال") {
           if ($time === "time00") {
      $text = $text3;
    } else if ($time === "time01") {
      $text = $text3;
    } else if ($time === "time02") {
      $text = $text3;
    } else if ($time === "time03") {
      $text = $text3;
    } else if ($time === "time04") {
      $text = $text3;
    } else if ($time === "time05") {
      $text = $text3;
    } else if ($time === "time06") {
      $text = $text3;
    } else if ($time === "time07") {
      $text = $text3;
    } else if ($time === "time08") {
      $text = $text3;
    } else if ($time === "time09") {
      $text = $text3;
    }else if ($time === "time10") {
      $text = $text3;
    } else if ($time === "time11") {
      $text = $text3;
    } else if ($time === "time12") {
      $text = $text3;
    } else if ($time === "time13") {
      $text = $text3;
    }else if ($time === "time14") {
      $text = $text3;
    } else if ($time === "time15") {
      $text = $text3;
    } else if ($time === "time16") {
      $text = $text3;
    } else if ($time === "time17") {
      $text = $text3;
    } else if ($time === "time18") {
      $text = $text3;
    } else if ($time === "time19") {
      $text = $text3;
    } else if ($time === "time20") {
      $text = $text3;
    } else if ($time === "time21") {
      $text = $text3;
    }else if ($time === "time22") {
      $text = $text3;
    } else if ($time === "time23") {
      $text = $text3;
    } else if ($time === "time24") {
      $text = $text3;
    } else if ($time === "time25") {
      $text = $text3;
    }else if ($time === "time26") {
      $text = $text3;
    } else if ($time === "time27") {
      $text = $text3;
    } else if ($time === "time28") {
      $text = $text3;
    } else if ($time === "time29") {
      $text = $text3;
    }else if ($time === "time30") {
      $text = $text3;
    } else if ($time === "time31") {
      $text = $text3;
    }
  } else if ($operator === "همه") {
           if ($time === "time00") {
      $text = $text0_time0;
    } else if ($time === "time01") {
      $text = $text0_time1;
    } else if ($time === "time02") {
      $text = $text0_time2;
    } else if ($time === "time03") {
      $text = $text0_time3;
    } else if ($time === "time04") {
      $text = $text0_time4;
    } else if ($time === "time05") {
      $text = $text0_time5;
    } else if ($time === "time06") {
      $text = $text0_time6;
    } else if ($time === "time07") {
      $text = $text0_time7;
    } else if ($time === "time08") {
      $text = $text0_time8;
    } else if ($time === "time09") {
      $text = $text0_time9;
    }else if ($time === "time10") {
      $text = $text0_time10;
    } else if ($time === "time11") {
      $text = $text0_time11;
    } else if ($time === "time12") {
      $text = $text0_time12;
    } else if ($time === "time13") {
      $text = $text0_time13;
    }else if ($time === "time14") {
      $text = $text0_time14;
    } else if ($time === "time15") {
      $text = $text0_time15;
    } else if ($time === "time16") {
      $text = $text0_time16;
    } else if ($time === "time17") {
      $text = $text0_time17;
    } else if ($time === "time18") {
      $text = $text0_time18;
    } else if ($time === "time19") {
      $text = $text0_time19;
    } else if ($time === "time20") {
      $text = $text0_time20;
    } else if ($time === "time21") {
      $text = $text0_time21;
    }else if ($time === "time22") {
      $text = $text0_time22;
    } else if ($time === "time23") {
      $text = $text0_time23;
    } else if ($time === "time24") {
      $text = $text0_time24;
    } else if ($time === "time25") {
      $text = $text0_time25;
    }else if ($time === "time26") {
      $text = $text0_time26;
    } else if ($time === "time27") {
      $text = $text0_time27;
    } else if ($time === "time28") {
      $text = $text0_time28;
    } else if ($time === "time29") {
      $text = $text0_time29;
    }else if ($time === "time30") {
      $text = $text0_time30;
    } else if ($time === "time31") {
      $text = $text0_time31;
    }
  }else if ($operator === "فرگمنت") {
           if ($time === "time00") {
      $text = $text4;
    } else if ($time === "time01") {
      $text = $text4;
    } else if ($time === "time02") {
      $text = $text4;
    } else if ($time === "time03") {
      $text = $text4;
    } else if ($time === "time04") {
      $text = $text4;
    } else if ($time === "time05") {
      $text = $text4;
    } else if ($time === "time06") {
      $text = $text4;
    } else if ($time === "time07") {
      $text = $text4;
    } else if ($time === "time08") {
      $text = $text4;
    } else if ($time === "time09") {
      $text = $text4;
    }else if ($time === "time10") {
      $text = $text4;
    } else if ($time === "time11") {
      $text = $text4;
    } else if ($time === "time12") {
      $text = $text4;
    } else if ($time === "time13") {
      $text = $text4;
    }else if ($time === "time14") {
      $text = $text4;
    } else if ($time === "time15") {
      $text = $text4;
    } else if ($time === "time16") {
      $text = $text4;
    } else if ($time === "time17") {
      $text = $text4;
    } else if ($time === "time18") {
      $text = $text4;
    } else if ($time === "time19") {
      $text = $text4;
    } else if ($time === "time20") {
      $text = $text4;
    } else if ($time === "time21") {
      $text = $text4;
    }else if ($time === "time22") {
      $text = $text4;
    } else if ($time === "time23") {
      $text = $text4;
    } else if ($time === "time24") {
      $text = $text4;
    } else if ($time === "time25") {
      $text = $text4;
    }else if ($time === "time26") {
      $text = $text4;
    } else if ($time === "time27") {
      $text = $text4;
    } else if ($time === "time28") {
      $text = $text4;
    } else if ($time === "time29") {
      $text = $text4;
    }else if ($time === "time30") {
      $text = $text4;
    } else if ($time === "time31") {
      $text = $text4;
    }
  }else if ($operator === "اختصاصی") {
           if ($time === "time00") {
      $text = $text5_time0;
    } else if ($time === "time01") {
      $text = $text5_time1;
    } else if ($time === "time02") {
      $text = $text5_time2;
    } else if ($time === "time03") {
      $text = $text5_time3;
    } else if ($time === "time04") {
      $text = $text5_time4;
    } else if ($time === "time05") {
      $text = $text5_time5;
    } else if ($time === "time06") {
      $text = $text5_time6;
    } else if ($time === "time07") {
      $text = $text5_time7;
    } else if ($time === "time08") {
      $text = $text5_time8;
    } else if ($time === "time09") {
      $text = $text5_time9;
    }else if ($time === "time10") {
      $text = $text5_time10;
    } else if ($time === "time11") {
      $text = $text5_time11;
    } else if ($time === "time12") {
      $text = $text5_time12;
    } else if ($time === "time13") {
      $text = $text5_time13;
    }else if ($time === "time14") {
      $text = $text5_time14;
    } else if ($time === "time15") {
      $text = $text5_time15;
    } else if ($time === "time16") {
      $text = $text5_time16;
    } else if ($time === "time17") {
      $text = $text5_time17;
    } else if ($time === "time18") {
      $text = $text5_time18;
    } else if ($time === "time19") {
      $text = $text5_time19;
    } else if ($time === "time20") {
      $text = $text5_time20;
    } else if ($time === "time21") {
      $text = $text5_time21;
    }else if ($time === "time22") {
      $text = $text5_time22;
    } else if ($time === "time23") {
      $text = $text5_time23;
    } else if ($time === "time24") {
      $text = $text5_time24;
    } else if ($time === "time25") {
      $text = $text5_time25;
    }else if ($time === "time26") {
      $text = $text5_time26;
    } else if ($time === "time27") {
      $text = $text5_time27;
    } else if ($time === "time28") {
      $text = $text5_time28;
    } else if ($time === "time29") {
      $text = $text5_time29;
    }else if ($time === "time30") {
      $text = $text5_time30;
    } else if ($time === "time31") {
      $text = $text5_time31;
    }
} 


        
// نام فایل را با پسوند .php مشخص کنید
$filename = 'sub/' . $name . '.php';
// محتوای فایل را بنویسید
file_put_contents($filename, $text);

}
?>





<!DOCTYPE html>
<html lang="fa">
        <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- عنوان صفحه  -->
    <link rel="icon" href="https://s8.uupload.ir/files/ic_stat_name_black_vtsi.png" type="image/png">    
    <link rel="stylesheet" href="https://cdn.rawgit.com/rastikerdar/vazir-font/v22.1.0/dist/font-face.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

   </head>

<body>
    <br><div class="container" >
           
          <div class="buttons">
                
 <?php echo "تمامی به روزرسانی ها با موفقیت انجام شد"; ?>
                
   </div>
        </div>
           
       <!---تولبار پایین صفحه---> 
   <div class="toolbar" style="position: fixed;bottom: 0;left: 0;width: 100%;height: 70px;background-color: #f94e60;display: flex;justify-content: space-around;align-items: center;border-top-left-radius: 50px;border-top-right-radius: 50px;border: 2px solid white;direction: rtl;">
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='customers.php'"><i class="fa fa-book"></i></button>
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='index.php'"><i class="fa fa-home"></i></button>
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='profile.php'"><i class="fa fa-user"></i></button>
  </div>               
</body>
</html>

<?php

// بستن اتصال به دیتابیس
$conn->close();
?>
