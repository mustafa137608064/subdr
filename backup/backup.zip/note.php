<?php
session_start();



if (!isset($_SESSION['user_id'])) {

    header('Location: login.php');

    exit;

}

include 'config.php';

// ایجاد اتصال به دیتابیس
$conn = new mysqli($servername, $username, $password, $dbname);

// دریافت نام و یادداشت
$name = $_POST['name'];
$note = $_POST['note'];

// آپدیت دیتابیس
$sql = "UPDATE customers SET note = '$note' WHERE name = '$name'";
$conn->query($sql);


// بستن اتصال
$conn->close();


// پیغام موفقیت آمیز
  echo "<script>";
  echo "alert('یادداشت جدید برای کاربر  " . $name . " با موفقیت ثبت شد');";
  echo "window.location.href = 'user.php?name=" . $name . "';";
  echo "</script>";


?>





