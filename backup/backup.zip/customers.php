<?php
session_start();



if (!isset($_SESSION['user_id'])) {

    header('Location: login.php');

    exit;

}

include "jdf.php";
include "config.php";
$today = jdate('Y/m/d');
$daysOfWeek = array('یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه');
$dayNumber = date('w');
        
?>
<html>
        <div style="display:none;">
        <?php
					include 'refresh.php';     
				?>
         </div>
</html>
<?php
// ایجاد اتصال به دیتابیس
$conn = new mysqli($servername, $username, $password, $dbname);
// دریافت نام و نوع شبکه مشتریان از دیتابیس
$sql = "SELECT name, operator, time, note FROM customers";
$result = $conn->query($sql);
// دریافت تمام نام های مشتریان
$stmt = $conn->query("SELECT name FROM customers");
$names = $stmt->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- عنوان صفحه  -->
    <title>مدیریت مشتری ها</title>
    <link rel="stylesheet" href="https://cdn.rawgit.com/rastikerdar/vazir-font/v22.1.0/dist/font-face.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function changeColor() {
const textElement = document.getElementById("color-text");
const currentColor = textElement.style.color;
if (currentColor === "red") {
textElement.style.color = "green";
} else {
textElement.style.color = "red";
}
}
setInterval(changeColor, 500); // تغییر رنگ هر ثانیه
</script>
   </head>
<body>
    <div class="container">
            <?php
                    ///شمارش تعداد افراد آنلاین
$db2 = new mysqli($servername, $username, $password, $dbname);
$sql2 = "SELECT page_name, date_time FROM ip_addresses ORDER BY date_time DESC";
$result2 = $db2->query($sql2);
$count_pages_under_5_minutes = 0;
if ($result2->num_rows > 0) {
    while ($row = $result2->fetch_assoc()) {
        $last_visit_timestamp = strtotime($row['date_time']);
        $current_timestamp = date('Y-m-d H:i:s');
        $date_time_tehran = date('Y-m-d H:i:s', strtotime($current_timestamp) + (3.5 * 3600));
        $date_time_online = strtotime($date_time_tehran);
        $minutes_diff = round(($date_time_online - $last_visit_timestamp) / 60);
        if ($minutes_diff < 5) {
            $count_pages_under_5_minutes++;
        }}}
echo "<div style='direction:rtl;' id='color-text'><i class='fa fa-circle'></i>" . $count_pages_under_5_minutes . "<span> کاربر آنلاین</span><i class='fa fa-circle'></i></div>";
 ?>
                <div style="direction:rtl;background-color: #f0f0f0;display:inline-block;flex-direction:row;padding:10px;">
                <!-- دکمه‌های ساخت مشتری -->
	<form action="create.php" method="post" style="display: inline-block; flex-direction: row;">
            <label for="time">👤:</label>
		<input class="navbarinput" type="text" name="name" placeholder="نام جدید را وارد کنید" required>
  		<input class="navbarbutton" type="submit" value="ایجاد👤">
	</form>
         <!-- دکمه‌های جستجو مشتری -->
    <form action="search.php" method="post" style="display: inline-block; flex-direction: row;">
            <label for="time">🔍:</label>
 	 <input class="navbarinput" type="text" name="search" placeholder="نام مشتری را وارد کنید">
     <input class="navbarbutton" type="submit" value="جستجو🔎" >
	</form>
     <!-- دکمه‌های تربیت بندی مشتری -->
        <form action="filter.php" method="post" style="display: inline-block; flex-direction: row;">
        <label for="time">🎰:</label>
        <select class="navbarinput" name="time" id="time">
            <option value="time00">♾️</option>
            <option value="time01">روز 1 ام</option>
            <option value="time02">روز 2 ام</option>
            <option value="time03">روز 3 ام</option>
            <option value="time04">روز 4 ام</option>
            <option value="time05">روز 5 ام</option>
            <option value="time06">روز 6 ام</option>
            <option value="time07">روز 7 ام</option>
            <option value="time08">روز 8 ام</option>
            <option value="time09">روز 9 ام</option>
            <option value="time10">روز 10 ام</option>
            <option value="time11">روز 11 ام</option>
            <option value="time12">روز 12 ام</option>
            <option value="time13">روز 13 ام</option>
            <option value="time14">روز 14 ام</option>
            <option value="time15">روز 15 ام</option>
            <option value="time16">روز 16 ام</option>
            <option value="time17">روز 17 ام</option>
            <option value="time18">روز 18 ام</option>
            <option value="time19">روز 19 ام</option>
            <option value="time20">روز 20 ام</option>
            <option value="time21">روز 21 ام</option>
            <option value="time22">روز 22 ام</option>
            <option value="time23">روز 23 ام</option>
            <option value="time24">روز 24 ام</option>
            <option value="time25">روز 25 ام</option>
            <option value="time26">روز 26 ام</option>
            <option value="time27">روز 27 ام</option>
            <option value="time28">روز 28 ام</option>
            <option value="time29">روز 29 ام</option>
            <option value="time30">روز 30 ام</option>
            <option value="time31">روز 31 ام</option>
        </select>
        <input class="navbarbutton" type="submit" value="نمایش🎰">
    	</form>
                        <?php
                        echo "<div>";
            				echo "<span style='margin:5px;'>$daysOfWeek[$dayNumber]</span>";
        					echo "<span style='margin:5px;'>$today</span>";
        				echo "</div>";
                        ?>
                <div style="border :2px solid #f04e60;"></div>    
        
  </div>
           
<?php
echo "<link rel='stylesheet' href='style.css'>";
// نمایش اطلاعات مشتریان                        
// کوئری برای شمارش کل رکوردها
$result_total = mysqli_query($conn, "SELECT COUNT(*) as total FROM customers");
$row_total = mysqli_fetch_assoc($result_total);
$total_records = $row_total['total'];
// تنظیمات صفحه بندی
$resultsPerPage = 10; // تعداد رکورد در هر صفحه
$currentPage = isset($_GET['page']) ? $_GET['page'] : 1; // شماره صفحه جاری
$offset = ($currentPage - 1) * $resultsPerPage;
// کوئری اصلی با محدودیت
$result = mysqli_query($conn, "SELECT * FROM customers ORDER BY counting DESC LIMIT $offset, $resultsPerPage");
if ($result->num_rows > 0) {
    echo "<table style='width: 80vw;margin: 0 auto;text-align:center;'>";
    $counter = 1; // تعریف و مقداردهی اولیه متغیر شمارنده
    echo "<thead>";
    // سرفصل‌های جدول (نام ستون‌ها)
    echo "<tr>";
    echo "<th>ردیف</th>";
    echo "<th>نام مشتری</th>";
    echo "<th>جزئیات</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        // نمایش داده‌های هر ردیف
        echo "<td style='border-bottom:1px solid red;'>" . $counter . "</td>";
        echo "<td style='border-bottom:1px solid red;'><h4>" . $row['name'] . "</h4></td>";
        echo "<td style='border-bottom:1px solid red;'><a style='text-decoration:none; color:white;background-color:#f94e60;padding:5px;border-radius:15px;border:1px solid white;' href='user.php?name=" . $row['name'] . "'>➕</a></td>";
        echo "</tr>";
        $counter++;
    }
    echo "</tbody>";
    echo "</table>";
}
// ایجاد لینک‌های صفحات
$totalPages = ceil($total_records / $resultsPerPage);
echo "<div class='pagination' style='margin:25px;margin-bottom:70px;'>";
for ($i = 1; $i <= $totalPages; $i++) {
    if ($i <= 3 || $i > $totalPages - 3) {
        echo "<a style='text-decoration:none; color:white;background-color:#f94e60;padding:5px;border-radius:15px;border:1px solid white;' href='?page=$i'>" . $i . "</a> ";
    } elseif ($i == 4) {
        echo "... ";}}
echo "</div>";
//echo "<br><br><br><br>";
// بستن اتصال
$conn->close();
?>

           
  </div>
          
       <!---تولبار پایین صفحه---> 
        
   <div class="toolbar" style="position: fixed;bottom: 0;left: 0;width: 100%;height: 70px;background-color: #f94e60;display: flex;justify-content: space-around;align-items: center;border-top-left-radius: 50px;border-top-right-radius: 50px;border: 2px solid white;direction: rtl;">
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='customers.php'"><i class="fa fa-book"></i></button>
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='index.php'"><i class="fa fa-home"></i></button>
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='profile.php'"><i class="fa fa-user"></i></button>
  </div>      
        
       
</body>
</html>


