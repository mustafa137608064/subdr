<?php
// اطلاعات اتصال به پایگاه داده
include '../config.php';
// دریافت مقادیر از دیتابیس
$sql = "SELECT day, month, year FROM times WHERE timename = 'time12'";
$conn = new mysqli($servername, $username, $password, $dbname);
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $day = $row["day"];
  $month = $row["month"];
  $year = $row["year"];
}
$conn->close();
// ساخت تاریخ مورد نظر
$target_date = "$year-$month-$day";
// تاریخ و زمان فعلی را دریافت کنید
$current_date = date('Y-m-d H:i:s');
// تفریق تاریخ و زمان فعلی از تاریخ و زمان مشخص
$difference = strtotime($target_date) - strtotime($current_date);
// محاسبه تعداد روزها
$days = floor($difference / 86400);
// ساخت متن نهایی
$ruze = " روز دیگر 📊";
$data = "vless://21c1c5e6-52fd-4e63-96d9-a7ec002f60aa@192.168.1.1:1111?mode=gun&security=tls&encryption=none&alpn=h2&fp=chrome&type=grpc&serviceName=#📊 زمان اتمام سرویس: ";
$string = implode('' , array($data , $days , $ruze));
// بررسی وجود فایل
if (!file_exists('../date/out/12')) {
file_put_contents('../date/out/12', '');}
$file = fopen("../date/out/12", "a"); // بازکردن فایل در حالت نوشتن
ftruncate($file, 0); // پاک کردن محتویات فایل
for ($i = 0; $i < 55; $i++) {fwrite($file, "\n");} // نوشتن 55 خط خالی در ابتدای فایل
fwrite($file, $string . "\n"); // نوشتن در فایل
fclose($file); //
?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <!-- عنوان صفحه  -->
    <title>تغییر مقادیر تاریخ</title>
    <link rel="stylesheet" href="https://cdn.rawgit.com/rastikerdar/vazir-font/v22.1.0/dist/font-face.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">   
    <style>
        body {
font-family: 'Vazir', sans-serif;margin: 0;display: flex;align-items: center;justify-content: center;height: 100vh;background: linear-gradient(to right, #f94e60, #f94e60, #f94e60, #f94e60); }
.container {text-align: center;padding: 20px;border: 2px solid #fff;border-radius: 15px;background-color: #f0f0f0;box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);max-width: 400px;width: 70%;}
.logo {border: none; background-color: transparent; border-radius: 50%; overflow: hidden;}
h1 {color: #494f4b; font-size: 36px;margin-bottom: 10px;}
.buttons {margin-top: 20px;}
.button {box-sizing: border-box;display: flex;align-items: center;justify-content: center;position: relative;width: 100%;padding: 18px 25px;margin: 10px 0;font-size: 18px;text-align: center;text-decoration: none;outline: none;background-color: #f94e60 ;color: #fff;border: 1px solid red;border-radius: 8px;cursor: pointer;transition: background-color 0.3s;overflow: hidden;}
.button:hover {background-color: red;}
.button::before {content: '';position: absolute;top: 0;left: -10px;width: 10px;height: 100%;background-color: red;border-top-left-radius: 8px;border-bottom-left-radius: 8px;transition: left 0.3s;}
.button:hover::before {left: 100%;}
.button i {display: flex;align-items: center;margin-left: 10px;}
.button.right-icon i,
.button.left-icon i {margin-left: 5px;position: absolute;top: 50%;transform: translateY(-50%);}
.button.right-icon i {left: auto;right: 25px;}
.button.left-icon i {left: auto;right: 25px;}
.button.right-icon i {margin-left: 3px;}
.fab.fa-telegram-plane:before { content: "\f3fe"; }
.fab.fa-list:before { content: "\f155"; }
.fab.fa-instagram:before { content: "\f16d"; }
 @media (max-width: 600px) {
.container {max-width: 90%;width: 300px;}
h1 {font-size: 20px;}
.button {padding: 12px 25px;font-size: 14px;padding-left: 2mm;padding-right: 25px;box-sizing: border-box;}
.button i {margin-left: 8px;}
.button.right-icon i {right: 75px;}
.server {background-color: lightblue;border-radius: 25px;padding: 15px;border: 1px solid blue;margin-top: 15px;text-align: center;}
.updateservers {background-color: green;color: white;border-radius: 25px;padding: 15px;border: 1px solid white;text-align: center;}                
</style>
</head>
<body>
    <div class="container">                 
        <div class="buttons">
               <h3 style="font-size: 15px; color: #666;">مقادیر تاریخ جدید برای روز 12 ام با موفقیت ثبت شد</h3>
 </div></div>
   <!---تولبار پایین صفحه---> 
   <div class="toolbar" style="position: fixed;bottom: 0;left: 0;width: 100%;height: 70px;background-color: #f94e60;display: flex;justify-content: space-around;align-items: center;border-top-left-radius: 50px;border-top-right-radius: 50px;border: 2px solid white;direction: rtl;">
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='../customers.php'"><i class="fa fa-book"></i></button>
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='../index.php'"><i class="fa fa-home"></i></button>
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;"onclick="window.location.href='../profile.php'"><i class="fa fa-user"></i></button>
  </div>                     
</body>
</html>
