<?php
// اطلاعات دیتابیس
include '../config.php';

// دریافت مقادیر از فرم
$day = $_POST['day'];
$month = $_POST['month'];
$year = $_POST['year'];
$timename = $_POST['timename'];


// ایجاد اتصال
$conn = new mysqli($servername, $username, $password, $dbname);

// بررسی اتصال
if ($conn->connect_error) {
  die("خطا در اتصال به پایگاه داده: " . $conn->connect_error);
}

// ساختن عبارت SQL
$sql = "UPDATE times SET day = ?, month = ?, year = ? WHERE timename = ?";

// آماده سازی عبارت SQL
$stmt = $conn->prepare($sql);

// اتصال مقادیر به عبارت SQL
$stmt->bind_param("ssss", $day, $month, $year, $timename);

// اجرای عبارت SQL
$stmt->execute();

// بستن اتصال
$stmt->close();
$conn->close();

// پیغام موفقیت آمیز
  echo "<script>";
  echo "alert('تاریج جدید برای روز" . $timename . " با موفقیت ثبت شد');";
  echo "window.location.href = '" . $timename . "edit.php';";
  echo "</script>";

?>

