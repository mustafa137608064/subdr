<?php
include 'config.php';
session_start();



if (!isset($_SESSION['user_id'])) {

    header('Location: login.php');

    exit;

}
include "jdf.php";

$today = jdate('Y/m/d');
$daysOfWeek = array('یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه');
$dayNumber = date('w');
        
?>


<html>
        <div style="display:none;">
        <?php
					include 'refresh.php';  
                
				?>
         </div>
</html>

<!DOCTYPE html>
<html lang="fa">
<head>
    <link rel="icon" href="https://s8.uupload.ir/files/ic_stat_name_black_vtsi.png" type="image/png">    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- عنوان صفحه  -->
    <title>پنل مدیریت VPN</title>

    <link rel="stylesheet" href="https://cdn.rawgit.com/rastikerdar/vazir-font/v22.1.0/dist/font-face.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
 <style>
        body {
font-family: 'Vazir', sans-serif;margin: 0;display: flex;align-items: center;justify-content: center;height: 100vh;background: linear-gradient(to right, #f94e60, #f94e60, #f94e60, #f94e60); }
.container {text-align: center;padding: 20px;border: 2px solid #fff;border-radius: 15px;background-color: #f0f0f0;box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);max-width: 400px;width: 70%;}
.logo {border: none; background-color: transparent; border-radius: 50%; overflow: hidden;}
h1 {color: #494f4b; font-size: 36px;margin-bottom: 10px;}
.buttons {margin-top: 20px;}
.button {box-sizing: border-box;display: flex;align-items: center;justify-content: center;position: relative;width: 100%;padding: 18px 25px;margin: 10px 0;font-size: 18px;text-align: center;text-decoration: none;outline: none;background-color: #f94e60 ;color: #fff;border: 1px solid red;border-radius: 8px;cursor: pointer;transition: background-color 0.3s;overflow: hidden;}
.button:hover {background-color: red;}
.button::before {content: '';position: absolute;top: 0;left: -10px;width: 10px;height: 100%;background-color: red;border-top-left-radius: 8px;border-bottom-left-radius: 8px;transition: left 0.3s;}
.button:hover::before {left: 100%;}
.button i {display: flex;align-items: center;margin-left: 10px;}
.button.right-icon i,
.button.left-icon i {margin-left: 5px;position: absolute;top: 50%;transform: translateY(-50%);}
.button.right-icon i {left: auto;right: 25px;}
.button.left-icon i {left: auto;right: 25px;}
.button.right-icon i {margin-left: 3px;}
.fab.fa-telegram-plane:before { content: "\f3fe"; }
.fab.fa-list:before { content: "\f155"; }
.fab.fa-instagram:before { content: "\f16d"; }
 @media (max-width: 600px) {
.container {max-width: 90%;width: 300px;}
h1 {font-size: 20px;}
.button {padding: 12px 25px;font-size: 14px;padding-left: 2mm;padding-right: 25px;box-sizing: border-box;}
.button i {margin-left: 8px;}
.button.right-icon i {right: 75px;}
.server {background-color: lightblue;border-radius: 25px;padding: 15px;border: 1px solid blue;margin-top: 15px;text-align: center;}
.updateservers {background-color: green;color: white;border-radius: 25px;padding: 15px;border: 1px solid white;text-align: center;}         
</style>
<script>
function changeColor() {
const textElement = document.getElementById("color-text");
const currentColor = textElement.style.color;
if (currentColor === "red") {
textElement.style.color = "green";
} else {
textElement.style.color = "red";
}
}
setInterval(changeColor, 500); // تغییر رنگ هر ثانیه
</script>
        <style>
        .tab {
                overflow: hidden;
                border: 3px solid #f94e60;
                background-color: #f1f1f1;
                border-radius:15px;
                text-align: center;
                display: flex;
                justify-content: center;
                }
                .tab button {
                  background-color: #ccc;
                  float: left;
                  border: 1px solid grey;
                  outline: none;
                  cursor: pointer;
                  padding: 10px 10px;
                  transition: 0.3s;
                  font-size: 17px;
                  border-radius: 15px;
                  margin: 5px;
                }
                .tab button i{
                        color:black;
                }
                .tab button i.acive{
                        color:white;
                }
                .tab button i:hover{
                        color:white;
                }
                .tab button:hover {
                  background-color: #f94e60;
                  border: 1px solid black;
                  border-radius: 15px;
                  color: white;
                }
                .tab button.active {
                  background-color: #f94e60;
                  border: 1px solid white;
                  border-radius: 15px;
                  color: white;      
                }
                .tabcontent {
                  display: none;
                  padding: 6px 12px;
                  -webkit-animation: fadeEffect 1s;
                  animation: fadeEffect 1s;
                }
                @-webkit-keyframes fadeEffect {                
                  from {opacity: 0;}
                  to {opacity: 1;}
                }
                @keyframes fadeEffect {
                  from {opacity: 0;}
                  to {opacity: 1;}
                }
        </style>
</head>
<body>
        
    <div class="container">
            
              <?php
                ///شمارش تعداد افراد آنلاین
$db2 = new mysqli($servername, $username, $password, $dbname);
$sql2 = "SELECT page_name, date_time FROM ip_addresses ORDER BY date_time DESC";
$result2 = $db2->query($sql2);
$count_pages_under_5_minutes = 0;
if ($result2->num_rows > 0) {
    while ($row = $result2->fetch_assoc()) {
        $last_visit_timestamp = strtotime($row['date_time']);
        $current_timestamp = date('Y-m-d H:i:s');
        $date_time_tehran = date('Y-m-d H:i:s', strtotime($current_timestamp) + (3.5 * 3600));
        $date_time_online = strtotime($date_time_tehran);
        $minutes_diff = round(($date_time_online - $last_visit_timestamp) / 60);
        if ($minutes_diff < 5) {
            $count_pages_under_5_minutes++;
        }}}
echo "<div style='direction:rtl;' id='color-text'><i class='fa fa-circle'></i>" . $count_pages_under_5_minutes . "<span> کاربر آنلاین</span><i class='fa fa-circle'></i></div>";
            echo "<span style='margin:5px;'>$daysOfWeek[$dayNumber]</span>";
        echo "<span style='margin:5px;'>$today</span>";

            ?>
             <!-- تب بندی -->      
    <div class="tab">
      <button class="tablinks" onclick="openCity(event, 'TabNames')" id="defaultOpen"><i class="	fa fa-address-card"></i></button>
      <button class="tablinks" onclick="openCity(event, 'TabServers')"><i class="fa fa-server"></i></button>
      <button class="tablinks" onclick="openCity(event, 'TabTimes')"><i class="fa fa-clock"></i></button>
      <button class="tablinks" onclick="openCity(event, 'TabOthers')"><i class="fa fa-navicon"></i></button>
     </div>
 
                 <!-- لوگوی صفحه -->
        <!--
<div class="logo">
            <img src="http://subdr.onlinewebshop.net/main/img/ic_logo.png" style="max-width:100px; max-height:100px;" alt="لوگو V2Plus">
        </div>
        -->
        <!-- عنوان اصلی صفحه --><!--
        <h1>مدیریت سرور V2Plus<br><span style="font-size: 14px; color: #000;">دانلود انواع نرم افزار اندروید با لینک مستقیم</span></h1>
        -->
        <!-- دکمه‌های ارتباطی -->
        <div class="buttons">
                <div id="TabNames" class="tabcontent">
            <a href="<?php echo "$link/customers.php"?>" class="button right-icon" ><i class="fa fa-address-book" style="color: white;"></i>مدیریت مشتریان</a>
            <a href="<?php echo "$link/ug.php"?>" class="button right-icon"  target="_blank"><i class="fab fa-github-square" style="color: white;"></i>ذخیره سازی در گیت هاب</a>
             <a href="<?php echo "$link/backup.php"?>" class="button right-icon" ><i class="fa fa-hdd"></i>بکاپ</a>    
                </div>
                <div id="TabServers" class="tabcontent">
            <a href="<?php echo "$link/Calendar.php"?>" class="button right-icon" ><i class="fa fa-calendar" style="color: pink;"></i>تقویم روزانه</a><a href="<?php echo "$link/ServersIrancell.php"?>" class="button right-icon" ><i class="fa fa-server" style="color: yellow;"></i>Irancell Servers</a>
            <a href="<?php echo "$link/ServersMCI.php"?>" class="button right-icon" ><i class="fa fa-server" style="color: blue;"></i>MCI Servers</a>
            <a href="<?php echo "$link/ServersFregmant.php"?>" class="button right-icon" ><i class="fa fa-server" style="color: purple;"></i>Fregmant Servers</a>
            <a href="https://github.com/mustafa13760806/v2ray" class="button right-icon" ><i class="fa fa-server" style="color: grey;"></i>GitHub Servers</a>
              	</div>
                <div id="TabTimes" class="tabcontent">
             <a href="<?php echo "$link/editimes.php"?>" class="button right-icon" ><i class="fa fa-clock"></i>زمانبندی ها</a>
                 </div>
                <div id="TabOthers" class="tabcontent">
             <a href="<?php echo "$link/history_show_all.php"?>" class="button right-icon" ><i class="fa fa-history"></i>تاریخچه</a>           
             <a href="<?php echo "$link/refresh.php"?>" class="button right-icon" ><i class="fa fa-spinner"></i>به روزرسانی</a>       
                        <a href="<?php echo "$link/github.php"?>" class="button right-icon"  target="_blank"><i class="fab fa-github-square" style="color: white;"></i>دانلود بکاپ مشتریان</a>
                        <a href="https://github.com/mustafa137608064/subdr/tree/main" class="button right-icon" target="_blank" ><i class="fab fa-github" style="color: white;"></i>GitHub</a>
                </div>        
            </div>
        
        
        </div>
        
        
        
        <div class="toolbar" style="position: fixed;bottom: 0;left: 0;width: 100%;height: 70px;background-color: #f94e60;display: flex;justify-content: space-around;align-items: center;border-top-left-radius: 50px;border-top-right-radius: 50px;border: 2px solid white;direction: rtl;">
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;" onclick="window.location.href='customers.php'"><i class="fa fa-book"></i></button>
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;" onclick="window.location.href='index.php'"><i class="fa fa-home"></i></button>
    <button style="margin: 0 10px;padding: 10px 20px;border: none;border-radius: 5px;background-color: #fff;color: #333;font-size: 16px;cursor: pointer;" onclick="window.location.href='profile.php'"><i class="fa fa-user"></i></button>
  </div>
        
        <!--اسکریپت تب بندی -->
          <script>
          function openCity(evt, cityName) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
              tabcontent[i].style.display = "none";
            }
            tablinks = document.getElementsByClassName("tablinks");
            for (i = 0; i < tablinks.length; i++) {
              tablinks[i].className = tablinks[i].className.replace(" active", "");
            }
            document.getElementById(cityName).style.display = "block";
            evt.currentTarget.className += " active";
          }
          document.getElementById("defaultOpen").click();
          </script>
        
</body>
</html>