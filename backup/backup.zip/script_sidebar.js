const openBtn = document.querySelector('.open-btn');
const closeBtn = document.querySelector('.close-btn');
const sidebar = document.querySelector('.sidebar');   

openBtn.addEventListener('click', () => {
    sidebar.classList.toggle('active');   
});

closeBtn.addEventListener('click', () => {
    sidebar.classList.remove('active');
});