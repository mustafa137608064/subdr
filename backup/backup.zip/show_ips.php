<?php

// نام صفحه را دریافت کنید
$page_name = $_POST['name'];

// اتصال به پایگاه داده
$db_connection = mysqli_connect('fdb1031.runhosting.com', '4428161_db', 'mustafa1234', '4428161_db');

// دریافت all IP ها برای نام صفحه
$sql_query = "SELECT ip_address, date_time FROM ip_addresses WHERE page_name = '$page_name'";
$result = mysqli_query($db_connection, $sql_query);

// نمایش all IP ها با دکمه حذف
$ip_found = false;
while ($row = mysqli_fetch_assoc($result)) {
  $ip_found = true;

  // ایجاد فرم با دکمه حذف
  
  echo "<p>🆔: {$row['ip_address']}</p>";
  echo "<p>⏳: {$row['date_time']}</p>";
  echo "<center><div style='display:flex;direction:rtl;text-align:center;margin:0 auto;'>";
  echo "<form action='delete_ip.php' method='post'>";
  echo "<input type='hidden' name='page_name' value='$page_name'>";
  echo "<input type='hidden' name='ip_address' value='{$row['ip_address']}'>";echo "<input type='submit' value='🗑️IP' style='margin:5px;background-color:#f94e60;border-radius:15px;padding-left:25px;padding-right:25px;padding-top:10px;border:3px solid red;padding-bottom:10px;color:white;'>";
  echo "</form>";
  echo "<div>";      
  echo "<button onclick='copyToClipboard(\"".$row['ip_address']."\")' style='margin:5px;background-color:green;;border-radius:15px;padding-left:25px;border:3px solid green;padding-right:25px;padding-top:10px;padding-bottom:10px;color:white;'>📝IP</button><br>";
  echo "</div>";
  echo "</div></center>";
  echo "<hr>";
}

// اگر IP ثبت نشده بود، عبارت "IP ثبت نشده" را نمایش دهید
if (!$ip_found) {
  echo "<p style='direction:rtl;'>در حال حاضر، هیچ IP ای برای $page_name ثبت نشده است.</p>";
}

// بستن اتصال به پایگاه داده
mysqli_close($db_connection);

?>


<script>
function copyToClipboard(text) {
  var dummy = document.createElement("input");
  document.body.appendChild(dummy);
  dummy.value = text;
  dummy.select();
  document.execCommand("copy");
  document.body.removeChild(dummy);
  alert("کپی شد! IP");
}
</script>