<?php

$link = "http://puzzle.social-networking.me/main";


// اطلاعات دیتابیس
$servername = "sql212.byetcluster.com";
$username = "35132954_e";
$password = "LbpS1l]9.8";
$dbname = "if0_35132954_puzzle";

// سرور های ایرانسل - همراه اول - غیرفعال - فرگمنت
$url1 = "./servers/ServersIrancell"; // URL to fetch text from
$url2 = "./servers/ServersMCI"; // URL to fetch text from
$url3 = "./servers/ExpiredServers"; // URL to fetch text from
$url4 = "./servers/ServersFeregmant"; // URL to fetch text from
$url5 = "./servers/allowip"; // URL to fetch text from
$url6 = "./servers/messages"; // URL to fetch text from messages
$url7 = "./servers/calender"; // URL to fetch text from calender 
$text1 = file_get_contents($url1); // Retrieve text from URL1
$text2 = file_get_contents($url2); // Retrieve text from URL2
$text3 = file_get_contents($url3); // Retrieve text from URL3
$text4 = file_get_contents($url4); // Retrieve text from URL4  FREGMANT
$text0 = $text2 . $text1;  // Retrieve text from URL1 + URL2
$textallowip = file_get_contents($url5); // Retrieve text from URL5
$textmessage = file_get_contents($url6); // Retrieve text from URL6
$calender = file_get_contents($url7); // Retrieve text from URL7



// متغیر های زمانی

$date00 = "./date/out/00";
$time00 = file_get_contents($date00);
$date01 = "./date/out/01";
$time01 = file_get_contents($date01);
$date02 = "./date/out/02";
$time02 = file_get_contents($date02);
$date03 = "./date/out/03";
$time03 = file_get_contents($date03);
$date04 = "./date/out/04";
$time04 = file_get_contents($date04);
$date05 = "./date/out/05";
$time05 = file_get_contents($date05);
$date06 = "./date/out/06";
$time06 = file_get_contents($date06);
$date07 = "./date/out/07";
$time07 = file_get_contents($date07);
$date08 = "./date/out/08";
$time08 = file_get_contents($date08);
$date09 = "./date/out/09";
$time09 = file_get_contents($date09);
$date10 = "./date/out/10";
$time10 = file_get_contents($date10);
$date11 = "./date/out/11";
$time11 = file_get_contents($date11);
$date12 = "./date/out/12";
$time12 = file_get_contents($date12);
$date13 = "./date/out/13";
$time13 = file_get_contents($date13);
$date14 = "./date/out/14";
$time14 = file_get_contents($date14);
$date15 = "./date/out/15";
$time15 = file_get_contents($date15);
$date16 = "./date/out/16";
$time16 = file_get_contents($date16);
$date17 = "./date/out/17";
$time17 = file_get_contents($date17);
$date18 = "./date/out/18";
$time18 = file_get_contents($date18);
$date19 = "./date/out/19";
$time19 = file_get_contents($date19);
$date20 = "./date/out/20";
$time20 = file_get_contents($date20);
$date21 = "./date/out/21";
$time21 = file_get_contents($date21);
$date22 = "./date/out/22";
$time22 = file_get_contents($date22);
$date23 = "./date/out/23";
$time23 = file_get_contents($date23);
$date24 = "./date/out/24";
$time24 = file_get_contents($date24);
$date25 = "./date/out/25";
$time25 = file_get_contents($date25);
$date26 = "./date/out/26";
$time26 = file_get_contents($date26);
$date27 = "./date/out/27";
$time27 = file_get_contents($date27);
$date28 = "./date/out/28";
$time28 = file_get_contents($date28);
$date29 = "./date/out/29";
$time29 = file_get_contents($date29);
$date30 = "./date/out/30";
$time30 = file_get_contents($date30);
$date31 = "./date/out/31";
$time31 = file_get_contents($date31);


// متغیر های اپراتور ها + متغیر های زمانی
$text0_time0 = $textallowip . $calender . $time00 . $textmessage . $text0 ;
$text0_time1 = $textallowip . $calender . $time01 . $textmessage . $text0 ;
$text0_time2 = $textallowip . $calender . $time02 . $textmessage . $text0 ;
$text0_time3 = $textallowip . $calender . $time03 . $textmessage . $text0 ;
$text0_time4 = $textallowip . $calender . $time04 . $textmessage . $text0 ;
$text0_time5 = $textallowip . $calender . $time05 . $textmessage . $text0 ;
$text0_time6 = $textallowip . $calender . $time06 . $textmessage . $text0 ;
$text0_time7 = $textallowip . $calender . $time07 . $textmessage . $text0 ;
$text0_time8 = $textallowip . $calender . $time08 . $textmessage . $text0 ;
$text0_time9 = $textallowip . $calender . $time09 . $textmessage . $text0 ;
$text0_time10 = $textallowip . $calender . $time10 . $textmessage . $text0 ;
$text0_time11 = $textallowip . $calender . $time11 . $textmessage . $text0 ;
$text0_time12 = $textallowip . $calender . $time12 . $textmessage . $text0 ;
$text0_time13 = $textallowip . $calender . $time13 . $textmessage . $text0 ;
$text0_time14 = $textallowip . $calender . $time14 . $textmessage . $text0 ;
$text0_time15 = $textallowip . $calender . $time15 . $textmessage . $text0 ;
$text0_time16 = $textallowip . $calender . $time16 . $textmessage . $text0 ;
$text0_time17 = $textallowip . $calender . $time17 . $textmessage . $text0 ;
$text0_time18 = $textallowip . $calender . $time18 . $textmessage . $text0 ;
$text0_time19 = $textallowip . $calender . $time19 . $textmessage . $text0 ;
$text0_time20 = $textallowip . $calender . $time20 . $textmessage . $text0 ;
$text0_time21 = $textallowip . $calender . $time21 . $textmessage . $text0 ;
$text0_time22 = $textallowip . $calender . $time22 . $textmessage . $text0 ;
$text0_time23 = $textallowip . $calender . $time23 . $textmessage . $text0 ;
$text0_time24 = $textallowip . $calender . $time24 . $textmessage . $text0 ;
$text0_time25 = $textallowip . $calender . $time25 . $textmessage . $text0 ;
$text0_time26 = $textallowip . $calender . $time26 . $textmessage . $text0 ;
$text0_time27 = $textallowip . $calender . $time27 . $textmessage . $text0 ;
$text0_time28 = $textallowip . $calender . $time28 . $textmessage . $text0 ;
$text0_time29 = $textallowip . $calender . $time29 . $textmessage . $text0 ;
$text0_time30 = $textallowip . $calender . $time30 . $textmessage . $text0 ;
$text0_time31 = $textallowip . $calender . $time31 . $textmessage . $text0 ;


$text1_time0 = $textallowip . $calender . $time00 . $textmessage . $text1 ;
$text1_time1 = $textallowip . $calender . $time01 . $textmessage . $text1 ;
$text1_time2 = $textallowip . $calender . $time02 . $textmessage . $text1 ;
$text1_time3 = $textallowip . $calender . $time03 . $textmessage . $text1 ;
$text1_time4 = $textallowip . $calender . $time04 . $textmessage . $text1 ;
$text1_time5 = $textallowip . $calender . $time05 . $textmessage . $text1 ;
$text1_time6 = $textallowip . $calender . $time06 . $textmessage . $text1 ;
$text1_time7 = $textallowip . $calender . $time07 . $textmessage . $text1 ;
$text1_time8 = $textallowip . $calender . $time08 . $textmessage . $text1 ;
$text1_time9 = $textallowip . $calender . $time09 . $textmessage . $text1 ;
$text1_time10 = $textallowip . $calender . $time10 . $textmessage . $text1 ;
$text1_time11 = $textallowip . $calender . $time11 . $textmessage . $text1 ;
$text1_time12 = $textallowip . $calender . $time12 . $textmessage . $text1 ;
$text1_time13 = $textallowip . $calender . $time13 . $textmessage . $text1 ;
$text1_time14 = $textallowip . $calender . $time14 . $textmessage . $text1 ;
$text1_time15 = $textallowip . $calender . $time15 . $textmessage . $text1 ;
$text1_time16 = $textallowip . $calender . $time16 . $textmessage . $text1 ;
$text1_time17 = $textallowip . $calender . $time17 . $textmessage . $text1 ;
$text1_time18 = $textallowip . $calender . $time18 . $textmessage . $text1 ;
$text1_time19 = $textallowip . $calender . $time19 . $textmessage . $text1 ;
$text1_time20 = $textallowip . $calender . $time20 . $textmessage . $text1 ;
$text1_time21 = $textallowip . $calender . $time21 . $textmessage . $text1 ;
$text1_time22 = $textallowip . $calender . $time22 . $textmessage . $text1 ;
$text1_time23 = $textallowip . $calender . $time23 . $textmessage . $text1 ;
$text1_time24 = $textallowip . $calender . $time24 . $textmessage . $text1 ;
$text1_time25 = $textallowip . $calender . $time25 . $textmessage . $text1 ;
$text1_time26 = $textallowip . $calender . $time26 . $textmessage . $text1 ;
$text1_time27 = $textallowip . $calender . $time27 . $textmessage . $text1 ;
$text1_time28 = $textallowip . $calender . $time28 . $textmessage . $text1 ;
$text1_time29 = $textallowip . $calender . $time29 . $textmessage . $text1 ;
$text1_time30 = $textallowip . $calender . $time30 . $textmessage . $text1 ;
$text1_time31 = $textallowip . $calender . $time31 . $textmessage . $text1 ;

$text2_time0 = $textallowip . $calender . $time00 . $textmessage . $text2 ;
$text2_time1 = $textallowip . $calender . $time01 . $textmessage . $text2 ;
$text2_time2 = $textallowip . $calender . $time02 . $textmessage . $text2 ;
$text2_time3 = $textallowip . $calender . $time03 . $textmessage . $text2 ;
$text2_time4 = $textallowip . $calender . $time04 . $textmessage . $text2 ;
$text2_time5 = $textallowip . $calender . $time05 . $textmessage . $text2 ;
$text2_time6 = $textallowip . $calender . $time06 . $textmessage . $text2 ;
$text2_time7 = $textallowip . $calender . $time07 . $textmessage . $text2 ;
$text2_time8 = $textallowip . $calender . $time08 . $textmessage . $text2 ;
$text2_time9 = $textallowip . $calender . $time09 . $textmessage . $text2 ;
$text2_time10 = $textallowip . $calender . $time10 . $textmessage . $text2 ;
$text2_time11 = $textallowip . $calender . $time11 . $textmessage . $text2 ;
$text2_time12 = $textallowip . $calender . $time12 . $textmessage . $text2 ;
$text2_time13 = $textallowip . $calender . $time13 . $textmessage . $text2 ;
$text2_time14 = $textallowip . $calender . $time14 . $textmessage . $text2 ;
$text2_time15 = $textallowip . $calender . $time15 . $textmessage . $text2 ;
$text2_time16 = $textallowip . $calender . $time16 . $textmessage . $text2 ;
$text2_time17 = $textallowip . $calender . $time17 . $textmessage . $text2 ;
$text2_time18 = $textallowip . $calender . $time18 . $textmessage . $text2 ;
$text2_time19 = $textallowip . $calender . $time19 . $textmessage . $text2 ;
$text2_time20 = $textallowip . $calender . $time20 . $textmessage . $text2 ;
$text2_time21 = $textallowip . $calender . $time21 . $textmessage . $text2 ;
$text2_time22 = $textallowip . $calender . $time22 . $textmessage . $text2 ;
$text2_time23 = $textallowip . $calender . $time23 . $textmessage . $text2 ;
$text2_time24 = $textallowip . $calender . $time24 . $textmessage . $text2 ;
$text2_time25 = $textallowip . $calender . $time25 . $textmessage . $text2 ;
$text2_time26 = $textallowip . $calender . $time26 . $textmessage . $text2 ;
$text2_time27 = $textallowip . $calender . $time27 . $textmessage . $text2 ;
$text2_time28 = $textallowip . $calender . $time28 . $textmessage . $text2 ;
$text2_time29 = $textallowip . $calender . $time29 . $textmessage . $text2 ;
$text2_time30 = $textallowip . $calender . $time30 . $textmessage . $text2 ;
$text2_time31 = $textallowip . $calender . $time31 . $textmessage . $text2 ;

$text3_time0 = $textallowip . $calender . $time00 . $textmessage . $text3 ;
$text3_time1 = $textallowip . $calender . $time01 . $textmessage . $text3 ;
$text3_time2 = $textallowip . $calender . $time02 . $textmessage . $text3 ;
$text3_time3 = $textallowip . $calender . $time03 . $textmessage . $text3 ;
$text3_time4 = $textallowip . $calender . $time04 . $textmessage . $text3 ;
$text3_time5 = $textallowip . $calender . $time05 . $textmessage . $text3 ;
$text3_time6 = $textallowip . $calender . $time06 . $textmessage . $text3 ;
$text3_time7 = $textallowip . $calender . $time07 . $textmessage . $text3 ;
$text3_time8 = $textallowip . $calender . $time08 . $textmessage . $text3 ;
$text3_time9 = $textallowip . $calender . $time09 . $textmessage . $text3 ;
$text3_time10 = $textallowip . $calender . $time10 . $textmessage . $text3 ;
$text3_time11 = $textallowip . $calender . $time11 . $textmessage . $text3 ;
$text3_time12 = $textallowip . $calender . $time12 . $textmessage . $text3 ;
$text3_time13 = $textallowip . $calender . $time13 . $textmessage . $text3 ;
$text3_time14 = $textallowip . $calender . $time14 . $textmessage . $text3 ;
$text3_time15 = $textallowip . $calender . $time15 . $textmessage . $text3 ;
$text3_time16 = $textallowip . $calender . $time16 . $textmessage . $text3 ;
$text3_time17 = $textallowip . $calender . $time17 . $textmessage . $text3 ;
$text3_time18 = $textallowip . $calender . $time18 . $textmessage . $text3 ;
$text3_time19 = $textallowip . $calender . $time19 . $textmessage . $text3 ;
$text3_time20 = $textallowip . $calender . $time20 . $textmessage . $text3 ;
$text3_time21 = $textallowip . $calender . $time21 . $textmessage . $text3 ;
$text3_time22 = $textallowip . $calender . $time22 . $textmessage . $text3 ;
$text3_time23 = $textallowip . $calender . $time23 . $textmessage . $text3 ;
$text3_time24 = $textallowip . $calender . $time24 . $textmessage . $text3 ;
$text3_time25 = $textallowip . $calender . $time25 . $textmessage . $text3 ;
$text3_time26 = $textallowip . $calender . $time26 . $textmessage . $text3 ;
$text3_time27 = $textallowip . $calender . $time27 . $textmessage . $text3 ;
$text3_time28 = $textallowip . $calender . $time28 . $textmessage . $text3 ;
$text3_time29 = $textallowip . $calender . $time29 . $textmessage . $text3 ;
$text3_time30 = $textallowip . $calender . $time30 . $textmessage . $text3 ;
$text3_time31 = $textallowip . $calender . $time31 . $textmessage . $text3 ;

$text5_time0 = $textallowip . $calender . $time00 . $textmessage ;
$text5_time1 = $textallowip . $calender . $time01 . $textmessage ;
$text5_time2 = $textallowip . $calender . $time02 . $textmessage ;
$text5_time3 = $textallowip . $calender . $time03 . $textmessage ;
$text5_time4 = $textallowip . $calender . $time04 . $textmessage ;
$text5_time5 = $textallowip . $calender . $time05 . $textmessage ;
$text5_time6 = $textallowip . $calender . $time06 . $textmessage ;
$text5_time7 = $textallowip . $calender . $time07 . $textmessage ;
$text5_time8 = $textallowip . $calender . $time08 . $textmessage ;
$text5_time9 = $textallowip . $calender . $time09 . $textmessage ;
$text5_time10 = $textallowip . $calender . $time10 . $textmessage ;
$text5_time11 = $textallowip . $calender . $time11 . $textmessage ;
$text5_time12 = $textallowip . $calender . $time12 . $textmessage ;
$text5_time13 = $textallowip . $calender . $time13 . $textmessage ;
$text5_time14 = $textallowip . $calender . $time14 . $textmessage ;
$text5_time15 = $textallowip . $calender . $time15 . $textmessage ;
$text5_time16 = $textallowip . $calender . $time16 . $textmessage ;
$text5_time17 = $textallowip . $calender . $time17 . $textmessage ;
$text5_time18 = $textallowip . $calender . $time18 . $textmessage ;
$text5_time19 = $textallowip . $calender . $time19 . $textmessage ;
$text5_time20 = $textallowip . $calender . $time20 . $textmessage ;
$text5_time21 = $textallowip . $calender . $time21 . $textmessage ;
$text5_time22 = $textallowip . $calender . $time22 . $textmessage ;
$text5_time23 = $textallowip . $calender . $time23 . $textmessage ;
$text5_time24 = $textallowip . $calender . $time24 . $textmessage ;
$text5_time25 = $textallowip . $calender . $time25 . $textmessage ;
$text5_time26 = $textallowip . $calender . $time26 . $textmessage ;
$text5_time27 = $textallowip . $calender . $time27 . $textmessage ;
$text5_time28 = $textallowip . $calender . $time28 . $textmessage ;
$text5_time29 = $textallowip . $calender . $time29 . $textmessage ;
$text5_time30 = $textallowip . $calender . $time30 . $textmessage ;
$text5_time31 = $textallowip . $calender . $time31 . $textmessage ;













?>